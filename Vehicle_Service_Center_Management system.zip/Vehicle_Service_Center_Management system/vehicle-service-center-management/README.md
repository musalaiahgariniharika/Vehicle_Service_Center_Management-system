# Apex Auto Care - Vehicle Service Center Management System

A full-stack enterprise web application designed for automobile repair centers, workshops, and vehicle owners. Built using pure **HTML5, CSS3, Vanilla JavaScript, Node.js, Express.js, and MySQL 8.0**.

---

## 1. Technology Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript (ES6+), Bootstrap 5.3, Bootstrap Icons (No React or other frontend frameworks)
- **Backend**: Node.js, Express.js
- **Database**: MySQL Server 8.0 (MySQL Workbench compatible)
- **MySQL Driver**: `mysql2` with Promise API and connection pooling
- **Security & Sessions**: `bcryptjs` for salted password hashing, `express-session` for secure HTTP session management
- **Configuration & Utilities**: `dotenv`, `cors`, `morgan`

---

## 2. Project Architecture & Directory Structure

```
vehicle-service-center-management/
│
├── config/
│   └── db.js                        # MySQL connection pool configuration
│
├── controllers/
│   ├── appointmentController.js     # Appointment booking and conversion logic
│   ├── authController.js            # Login, registration, session, logout
│   ├── customerController.js        # Customer CRUD and vehicle history
│   ├── dashboardController.js       # Dynamic multi-role statistical metrics
│   ├── mechanicController.js        # Mechanic roster and job assignments
│   ├── paymentController.js         # Transaction-safe payments and receipts
│   ├── reportController.js          # Reports and analytics generation
│   ├── serviceController.js         # Service orders and mechanic progress
│   └── vehicleController.js         # Vehicle registration and management
│
├── database/
│   ├── schema.sql                   # MySQL database schema (8 tables, constraints, indexes)
│   └── initDb.js                    # Automated DB initialization and seeding script
│
├── middleware/
│   └── authMiddleware.js            # Authentication and Role-Based Access Control (RBAC)
│
├── public/
│   ├── css/
│   │   └── style.css                # Automotive dark-blue, white, and cool-grey theme
│   ├── js/
│   │   └── main.js                  # Shared client engine (RBAC, toasts, currency formatters)
│   ├── appointments.html            # Service appointment booking & approval workflow
│   ├── customers.html               # Customer management & client history
│   ├── dashboard.html               # Dynamic multi-role dashboard (Admin, Customer, Mechanic)
│   ├── index.html                   # Public showcase & landing page
│   ├── login.html                   # Multi-role authentication with 1-click test fill
│   ├── mechanics.html               # Mechanic technician roster & assignments
│   ├── payments.html                # Billing desk, partial payments & printable tax receipts
│   ├── register.html                # Customer self-registration portal
│   ├── reports.html                 # Comprehensive reports, print view, and CSV export
│   └── vehicles.html                # Vehicle registration and fleet overview
│
├── routes/
│   ├── appointmentRoutes.js         # REST endpoints for appointments
│   ├── authRoutes.js                # REST endpoints for auth
│   ├── customerRoutes.js            # REST endpoints for customers
│   ├── dashboardRoutes.js           # REST endpoints for dashboard stats
│   ├── mechanicRoutes.js            # REST endpoints for mechanics
│   ├── paymentRoutes.js             # REST endpoints for payments & receipts
│   ├── reportRoutes.js              # REST endpoints for reports
│   ├── serviceRoutes.js             # REST endpoints for service jobs
│   └── vehicleRoutes.js             # REST endpoints for vehicles
│
├── .env                             # Environment configuration
├── .env.example                     # Environment template
├── package.json                     # Node.js project manifest & dependencies
├── README.md                        # Project documentation
└── server.js                        # Express server entry point
```

---

## 3. Database Schema (`vehicle_service_center`)

The database contains 8 interconnected tables with foreign key constraints, indexing, and cascade rules:

1. **`admins`**: Administrator accounts (`admin_id`, `username`, `password`, `name`, `created_at`).
2. **`customers`**: Vehicle owners (`customer_id`, `name`, `phone`, `email`, `password`, `address`, `created_at`).
3. **`vehicles`**: Registered vehicles (`vehicle_id`, `customer_id` FK, `vehicle_number` UNIQUE, `vehicle_model`, `vehicle_type`, `created_at`).
4. **`mechanics`**: Certified technicians (`mechanic_id`, `name`, `phone`, `email`, `specialization`, `password`, `status`, `created_at`).
5. **`services`**: Workshop service orders (`service_id`, `vehicle_id` FK, `service_type`, `service_date`, `description`, `service_charge`, `status`, `created_at`, `updated_at`).
6. **`service_assignments`**: Assigned technicians (`assignment_id`, `service_id` FK, `mechanic_id` FK, `assigned_date`, `remarks`, `created_at`).
7. **`payments`**: Transaction records (`payment_id`, `service_id` FK, `amount`, `payment_date`, `payment_method`, `status`, `receipt_number` UNIQUE, `notes`, `created_at`).
8. **`appointments`**: Online bookings (`appointment_id`, `customer_id` FK, `vehicle_id` FK, `appointment_date`, `appointment_time`, `service_type`, `description`, `status`, `created_at`).

---

## 4. Default Seed Credentials (1-Click Test Access)

The login screen (`login.html`) provides quick-fill buttons for each role:

| Role | Username / Email | Password | Access Capabilities |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin` | `admin123` | Full system control: Manage customers, vehicles, mechanics, appointments, convert to service, billing, and reports. |
| **Mechanic** | `john.mechanic@vsc.com` | `mechanic123` | Assigned repair orders, update status (Inspection, In Progress, Waiting for Parts, Completed), add technical notes. |
| **Customer** | `alice@gmail.com` | `customer123` | Register own vehicles, request appointments, track service progress, view invoices and receipts. |

Additional seed accounts:
- Mechanics: `mike.brake@vsc.com` (pass: `mechanic123`), `alex.electric@vsc.com` (pass: `mechanic123`)
- Customers: `robert@yahoo.com` (pass: `customer123`), `priya@outlook.com` (pass: `customer123`)

---

## 5. Key Business Logic & Financial Integrity Rules

- **ACID Transactions**: Payments utilize MySQL transactions (`beginTransaction`, `FOR UPDATE` row lock, `commit`, `rollback`) ensuring financial integrity.
- **Accurate Balance Calculation**:
  $$\text{Remaining Balance} = \text{Service Charge} - \sum \text{Paid Amounts}$$
- **Overpayment Prevention**: The system validates that payments cannot exceed the remaining balance.
- **Partial Payments**: Supports installments and partial advance deposits.
- **Safe Deletion Guards**:
  - Customers cannot be deleted if active services or payment transactions exist.
  - Vehicles cannot be deleted if ongoing work exists.
  - Service orders cannot be deleted if payment history exists.
- **Service Workflow Stages**:
  `Received` $\rightarrow$ `Inspection` $\rightarrow$ `In Progress` $\rightarrow$ `Waiting for Parts` $\rightarrow$ `Completed` $\rightarrow$ `Delivered` (or `Cancelled`).
- **Appointment Conversion**: Admins can convert approved appointments directly into workshop service orders with one click.
- **Printable Invoices**: Official formatted tax receipts with company branding, itemized vehicle specifics, and printer-friendly stylesheets (`@media print`).
- **Exporting**: Instant CSV export for all reporting categories.

---

## 6. How to Start and Run the Application

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Initialize & Seed Database
```bash
npm run init-db
```
*(This automatically connects to your local MySQL Server, creates the `vehicle_service_center` database, creates all 8 tables with proper foreign keys and constraints, and seeds realistic test data).*

### Step 3: Start Server
```bash
npm start
```

### Step 4: Open in Browser
Open `http://localhost:3000` in your web browser.
