const mysql = require('mysql2/promise');

const passwordsToTest = ['', 'root', 'password', 'admin', '1234', '123456', 'MySQL80', 'root123'];

async function test() {
  console.log('Testing MySQL connections on localhost:3306...');
  let connected = false;
  let successfulConfig = null;

  for (const pwd of passwordsToTest) {
    try {
      const conn = await mysql.createConnection({
        host: 'localhost',
        port: 3306,
        user: 'root',
        password: pwd,
        connectTimeout: 2000
      });
      console.log(` SUCCESS: Connected as root with password: "${pwd}"`);
      await conn.end();
      connected = true;
      successfulConfig = { host: 'localhost', user: 'root', password: pwd };
      break;
    } catch (err) {
      console.log(` Failed for password "${pwd}": ${err.code || err.message}`);
      if (err.code === 'ECONNREFUSED') {
        console.log(' MySQL Server is not running on port 3306 or connection refused.');
        break;
      }
    }
  }

  if (!connected) {
    console.log('Could not connect with standard test credentials.');
  }
}

test();
