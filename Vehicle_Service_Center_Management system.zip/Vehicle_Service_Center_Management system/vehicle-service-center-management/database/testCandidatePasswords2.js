const mysql = require('mysql2/promise');

const passwordsToTest = [
  '3683', 'mahesh3683', 'Mahesh3683', 'Mahesh@3683', 'maheshyadav', 'MaheshYadav',
  'Mahesh@Yadav', 'niharika', 'Niharika', 'niharika@123', 'Niharika@123',
  'musalaiahgari', 'Musalaiahgari', '12345', 'root@localhost', 'localhost',
  'mysql123', 'mysql@123', 'rootpassword', 'toor'
];

async function test() {
  for (const pwd of passwordsToTest) {
    try {
      const conn = await mysql.createConnection({
        host: 'localhost',
        port: 3306,
        user: 'root',
        password: pwd,
        connectTimeout: 1500
      });
      console.log(`FOUND_PASSWORD: "${pwd}"`);
      await conn.end();
      return;
    } catch (err) {
      // ignore
    }
  }
  console.log('NOT_FOUND');
}

test();
