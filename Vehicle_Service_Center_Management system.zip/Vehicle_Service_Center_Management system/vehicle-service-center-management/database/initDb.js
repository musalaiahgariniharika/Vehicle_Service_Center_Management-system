require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

async function initDatabase() {
  console.log('--- Initializing Vehicle Service Center Database ---');
  
  const host = process.env.DB_HOST || 'localhost';
  const user = process.env.DB_USER || 'root';
  const password = process.env.DB_PASSWORD || 'niha123';
  const port = parseInt(process.env.DB_PORT || '3306', 10);
  const dbName = process.env.DB_NAME || 'vehicle_service_center';

  let connection;
  try {
    // 1. Connect without database to create the database if not exists
    connection = await mysql.createConnection({ host, user, password, port, multipleStatements: true });
    console.log(`Connected to MySQL Server at ${host}:${port} as ${user}.`);

    const schemaPath = path.join(__dirname, 'schema.sql');
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');

    console.log('Executing database schema...');
    await connection.query(schemaSql);
    console.log(`Database "${dbName}" and all 8 tables created successfully.`);

    // Switch to target database
    await connection.changeUser({ database: dbName });

    // 2. Hash passwords
    const adminHash = await bcrypt.hash('admin123', 10);
    const mechanicHash = await bcrypt.hash('mechanic123', 10);
    const customerHash = await bcrypt.hash('customer123', 10);

    // 3. Seed Admins
    console.log('Seeding initial admin...');
    await connection.query(
      `INSERT INTO admins (admin_id, username, password, name) 
       VALUES (1, 'admin', ?, 'Master Administrator')
       ON DUPLICATE KEY UPDATE password = VALUES(password), name = VALUES(name);`,
      [adminHash]
    );

    // 4. Seed Mechanics
    console.log('Seeding mechanics...');
    const mechanics = [
      [1, 'John Davis', '9876543210', 'john.mechanic@vsc.com', 'Engine Specialist & Diagnostics', mechanicHash, 'Active'],
      [2, 'Mike Miller', '9876543211', 'mike.brake@vsc.com', 'Brakes & Suspension', mechanicHash, 'Active'],
      [3, 'Alex Carter', '9876543212', 'alex.electric@vsc.com', 'Electrical & AC Systems', mechanicHash, 'Active']
    ];
    for (const m of mechanics) {
      await connection.query(
        `INSERT INTO mechanics (mechanic_id, name, phone, email, specialization, password, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE name=VALUES(name), phone=VALUES(phone), specialization=VALUES(specialization), status=VALUES(status);`,
        m
      );
    }

    // 5. Seed Customers
    console.log('Seeding customers...');
    const customers = [
      [1, 'Alice Smith', '9123456780', 'alice@gmail.com', customerHash, '123 Park Avenue, Downtown'],
      [2, 'Robert Johnson', '9123456781', 'robert@yahoo.com', customerHash, '456 Elm Street, Suburb'],
      [3, 'Priya Patel', '9123456782', 'priya@outlook.com', customerHash, '789 Sunset Blvd, Midtown']
    ];
    for (const c of customers) {
      await connection.query(
        `INSERT INTO customers (customer_id, name, phone, email, password, address)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE name=VALUES(name), phone=VALUES(phone), address=VALUES(address);`,
        c
      );
    }

    // 6. Seed Vehicles
    console.log('Seeding vehicles...');
    const vehicles = [
      [1, 1, 'KA-01-AB-1234', 'Honda Civic 2021', 'Sedan'],
      [2, 1, 'KA-01-CD-5678', 'Hyundai Creta 2022', 'SUV'],
      [3, 2, 'MH-02-XY-9876', 'Toyota Fortuner 2020', 'SUV'],
      [4, 3, 'TN-07-ZZ-4321', 'Yamaha R15 V4', 'Bike']
    ];
    for (const v of vehicles) {
      await connection.query(
        `INSERT INTO vehicles (vehicle_id, customer_id, vehicle_number, vehicle_model, vehicle_type)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE vehicle_model=VALUES(vehicle_model), vehicle_type=VALUES(vehicle_type);`,
        v
      );
    }

    // 7. Seed Services
    console.log('Seeding services...');
    const services = [
      [1, 1, 'Full Periodic Maintenance & Engine Tune-up', '2026-11-01', 'Complete oil flush, filter change, spark plugs cleaning, battery health check, and tire rotation.', 4500.00, 'Completed'],
      [2, 2, 'Brake Pad Replacement & Rotor Resurfacing', '2026-11-05', 'Front ceramic brake pads installed and rotors resurfaced to factory tolerance.', 3200.00, 'In Progress'],
      [3, 3, 'AC Compressor Service & Gas Refill', '2026-11-06', 'High-pressure refrigerant recharge, cabin pollen filter cleaning, and condenser wash.', 2800.00, 'Inspection'],
      [4, 4, 'Periodic Bike Service & Chain Lube', '2026-11-07', 'Engine oil change, chain slack adjustment and lubrication, front brake cable replacement.', 1200.00, 'Received']
    ];
    for (const s of services) {
      await connection.query(
        `INSERT INTO services (service_id, vehicle_id, service_type, service_date, description, service_charge, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE service_charge=VALUES(service_charge), status=VALUES(status);`,
        s
      );
    }

    // 8. Seed Service Assignments
    console.log('Seeding service assignments...');
    const assignments = [
      [1, 1, 1, '2026-11-01 09:30:00', 'Full service completed thoroughly. Engine test drive successful.'],
      [2, 2, 2, '2026-11-05 10:15:00', 'Brake pads replaced; currently bedding the new ceramic pads.'],
      [3, 3, 3, '2026-11-06 14:00:00', 'Compressor pressure check underway. Refrigerant level tested.']
    ];
    for (const a of assignments) {
      await connection.query(
        `INSERT INTO service_assignments (assignment_id, service_id, mechanic_id, assigned_date, remarks)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE remarks=VALUES(remarks);`,
        a
      );
    }

    // 9. Seed Payments
    console.log('Seeding payments...');
    const payments = [
      [1, 1, 4500.00, '2026-11-01', 'Card', 'Paid', 'REC-20261101-0001', 'Full payment settled via HDFC Credit Card.'],
      [2, 2, 1500.00, '2026-11-05', 'UPI', 'Paid', 'REC-20261105-0002', 'Advance payment received via Google Pay UPI.']
    ];
    for (const p of payments) {
      await connection.query(
        `INSERT INTO payments (payment_id, service_id, amount, payment_date, payment_method, status, receipt_number, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE amount=VALUES(amount), status=VALUES(status);`,
        p
      );
    }

    // 10. Seed Appointments
    console.log('Seeding appointments...');
    const appointments = [
      [1, 3, 4, '2026-11-10', '10:00:00', 'General Bike Service & Chain Lubrication', 'Engine making slight ticking noise at idle. Request morning slot.', 'Approved'],
      [2, 2, 3, '2026-11-12', '14:00:00', 'Wheel Alignment & Balancing', 'Car pulling slightly to the left on highway speeds.', 'Pending'],
      [3, 1, 1, '2026-11-15', '11:30:00', 'Windshield Wiper & Battery Check', 'Wiper rubber worn out; please test battery cranking amperage.', 'Pending']
    ];
    for (const app of appointments) {
      await connection.query(
        `INSERT INTO appointments (appointment_id, customer_id, vehicle_id, appointment_date, appointment_time, service_type, description, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE status=VALUES(status);`,
        app
      );
    }

    console.log('--- Verification: Checking Created Tables in MySQL ---');
    const [tables] = await connection.query('SHOW TABLES;');
    console.log('Tables present in vehicle_service_center:', tables.map(t => Object.values(t)[0]));

    console.log(' Database initialization completed successfully!');
    process.exit(0);
  } catch (err) {
    console.error('Database initialization failed:', err);
    process.exit(1);
  } finally {
    if (connection) await connection.end();
  }
}

initDatabase();
