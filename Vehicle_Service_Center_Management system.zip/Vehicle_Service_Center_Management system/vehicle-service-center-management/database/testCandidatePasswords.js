const mysql = require('mysql2/promise');

const passwordsToTest = [
  'mahesh', 'Mahesh', 'mahes', 'Mahes',
  'mahesh@123', 'Mahesh@123', 'Mahesh#123', 'mahesh123',
  'gpcet', 'Gpcet', 'GPCET', 'gpcet@123', 'Gpcet@123',
  '12345678', '123456789', 'mysql', 'MySQL', 'MySQL80',
  'root@123', 'Root@123', 'Root123', 'Admin@123', 'admin123',
  'password123', 'Password@123', 'Pass@123', 'Password123'
];

async function test() {
  for (const pwd of passwordsToTest) {
    try {
      const conn = await mysql.createConnection({
        host: 'localhost',
        port: 3306,
        user: 'root',
        password: pwd,
        connectTimeout: 1500
      });
      console.log(`FOUND_PASSWORD: "${pwd}"`);
      await conn.end();
      return;
    } catch (err) {
      // ignore
    }
  }
  console.log('NOT_FOUND');
}

test();
