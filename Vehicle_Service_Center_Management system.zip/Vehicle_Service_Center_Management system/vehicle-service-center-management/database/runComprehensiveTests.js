require('dotenv').config();
const http = require('http');
const db = require('../config/db');
const app = require('../server');

let server;
let port = 3001; // use separate test port or 3000

function httpRequest(options, postData = null, cookie = null) {
  return new Promise((resolve, reject) => {
    const headers = options.headers || {};
    if (postData) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(JSON.stringify(postData));
    }
    if (cookie) {
      headers['Cookie'] = cookie;
    }
    options.headers = headers;

    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        let setCookie = res.headers['set-cookie'];
        let cookieHeader = null;
        if (setCookie) {
          cookieHeader = setCookie[0].split(';')[0];
        }
        try {
          const parsed = JSON.parse(body);
          resolve({ status: res.statusCode, data: parsed, cookie: cookieHeader });
        } catch (e) {
          resolve({ status: res.statusCode, body, cookie: cookieHeader });
        }
      });
    });

    req.on('error', err => reject(err));
    if (postData) {
      req.write(JSON.stringify(postData));
    }
    req.end();
  });
}

async function runTests() {
  console.log('====================================================');
  console.log('  STARTING COMPREHENSIVE AUTOMATED TEST SUITE');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, testName) {
    if (condition) {
      console.log(` PASS: ${testName}`);
      passed++;
    } else {
      console.error(` FAIL: ${testName}`);
      failed++;
    }
  }

  // Start test server
  await new Promise(resolve => {
    server = app.listen(port, () => {
      console.log(`Test server running on port ${port}...\n`);
      resolve();
    });
  });

  try {
    // 1. Verify DB Connection and Tables
    console.log('[1/12] Testing MySQL Database and Tables Creation...');
    const [tables] = await db.query('SHOW TABLES;');
    const tableNames = tables.map(t => Object.values(t)[0]);
    const expectedTables = ['admins', 'customers', 'vehicles', 'services', 'payments', 'mechanics', 'appointments', 'service_assignments'];
    const allTablesExist = expectedTables.every(t => tableNames.includes(t));
    assert(allTablesExist, 'All 8 required database tables exist in MySQL');

    // 2. Test Admin Login
    console.log('\n[2/12] Testing Admin Authentication...');
    const adminLoginRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/auth/login',
      method: 'POST'
    }, { usernameOrEmail: 'admin', password: 'admin123', role: 'admin' });

    assert(adminLoginRes.status === 200 && adminLoginRes.data.success && adminLoginRes.data.user.role === 'admin', 'Admin login with valid credentials succeeds');
    const adminCookie = adminLoginRes.cookie;

    // Test Invalid Admin Login
    const badLoginRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/auth/login',
      method: 'POST'
    }, { usernameOrEmail: 'admin', password: 'wrongpassword', role: 'admin' });
    assert(badLoginRes.status === 401 && !badLoginRes.data.success, 'Invalid password correctly rejected with 401');

    // 3. Test Customer Login & Registration
    console.log('\n[3/12] Testing Customer Authentication & Registration...');
    const custLoginRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/auth/login',
      method: 'POST'
    }, { usernameOrEmail: 'alice@gmail.com', password: 'customer123', role: 'customer' });
    assert(custLoginRes.status === 200 && custLoginRes.data.user.role === 'customer', 'Customer login with valid credentials succeeds');
    const customerCookie = custLoginRes.cookie;

    // Customer self-registration test
    const newCustEmail = `testuser_${Date.now()}@example.com`;
    const regRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/auth/register',
      method: 'POST'
    }, {
      name: 'Test Automatic User',
      email: newCustEmail,
      phone: `99${Math.floor(10000000 + Math.random() * 90000000)}`,
      password: 'testpassword123',
      address: '777 Test Road'
    });
    assert(regRes.status === 201 && regRes.data.success, 'Customer self-registration succeeds and auto-logs in');

    // 4. Test Mechanic Authentication
    console.log('\n[4/12] Testing Mechanic Authentication...');
    const mechLoginRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/auth/login',
      method: 'POST'
    }, { usernameOrEmail: 'john.mechanic@vsc.com', password: 'mechanic123', role: 'mechanic' });
    assert(mechLoginRes.status === 200 && mechLoginRes.data.user.role === 'mechanic', 'Mechanic login with valid credentials succeeds');
    const mechanicCookie = mechLoginRes.cookie;

    // 5. Test Customer Management (Admin CRUD & search)
    console.log('\n[5/12] Testing Customer CRUD & Search...');
    const custListRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/customers?search=Alice',
      method: 'GET'
    }, null, adminCookie);
    assert(custListRes.status === 200 && custListRes.data.data.length > 0 && custListRes.data.data[0].name.includes('Alice'), 'Customer search by name returns Alice');

    // Customer detail with vehicles & service history
    const custDetailRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/customers/1',
      method: 'GET'
    }, null, adminCookie);
    assert(custDetailRes.status === 200 && custDetailRes.data.data.vehicles.length > 0, 'Customer profile returns registered vehicles and service history');

    // 6. Test Vehicle CRUD & Unique Plate Enforcement
    console.log('\n[6/12] Testing Vehicle Fleet CRUD & Unique Plate Check...');
    const testPlate = `TEST-${Math.floor(1000 + Math.random() * 9000)}`;
    const newVehRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/vehicles',
      method: 'POST'
    }, {
      customer_id: 1,
      vehicle_number: testPlate,
      vehicle_model: 'Mazda CX-5',
      vehicle_type: 'SUV'
    }, adminCookie);
    assert(newVehRes.status === 201 && newVehRes.data.success, 'Vehicle registration succeeds');
    const createdVehicleId = newVehRes.data.vehicleId;

    // Try duplicate plate
    const dupVehRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/vehicles',
      method: 'POST'
    }, {
      customer_id: 1,
      vehicle_number: testPlate,
      vehicle_model: 'Another Car',
      vehicle_type: 'Sedan'
    }, adminCookie);
    assert(dupVehRes.status === 409 && !dupVehRes.data.success, 'Duplicate license plate is prevented (409 Conflict)');

    // 7. Test Appointment Creation, Approval & Conversion
    console.log('\n[7/12] Testing Appointment Management & Service Conversion...');
    const futureDate = new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0];
    const appCreateRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/appointments',
      method: 'POST'
    }, {
      vehicle_id: createdVehicleId,
      appointment_date: futureDate,
      appointment_time: '10:00:00',
      service_type: 'Comprehensive Brake & Rotor Service',
      description: 'Squeaking sound when braking at low speeds.'
    }, customerCookie);
    assert(appCreateRes.status === 201 && appCreateRes.data.success, 'Customer books appointment request successfully');
    const appointmentId = appCreateRes.data.appointmentId;

    // Admin approves appointment
    const approveRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: `/api/appointments/${appointmentId}/status`,
      method: 'PUT'
    }, { status: 'Approved' }, adminCookie);
    assert(approveRes.status === 200 && approveRes.data.success, 'Admin successfully approves appointment');

    // Admin converts appointment to active service record
    const convertRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: `/api/appointments/${appointmentId}/convert-to-service`,
      method: 'POST'
    }, {
      service_charge: 3500.00,
      mechanic_id: 2,
      description: 'Converted for brake specialist Mike'
    }, adminCookie);
    assert(convertRes.status === 201 && convertRes.data.serviceId, 'Admin converts approved appointment into active workshop service record');
    const convertedServiceId = convertRes.data.serviceId;

    // 8. Test Service CRUD & Mechanic Progress Updates
    console.log('\n[8/12] Testing Service Records & Mechanic Updates...');
    const srvDetailRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: `/api/services/${convertedServiceId}`,
      method: 'GET'
    }, null, adminCookie);
    assert(srvDetailRes.status === 200 && srvDetailRes.data.data.service_charge == 3500.00, 'Service record holds correct initial charge');

    // Mechanic logs inspection progress & repair remarks
    // Note: mechanic 2 is Mike Miller
    const mikeLoginRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/auth/login',
      method: 'POST'
    }, { usernameOrEmail: 'mike.brake@vsc.com', password: 'mechanic123', role: 'mechanic' });
    const mikeCookie = mikeLoginRes.cookie;

    const mechUpdateRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: `/api/services/${convertedServiceId}/mechanic-update`,
      method: 'PUT'
    }, {
      status: 'In Progress',
      remarks: 'Inspected brake calipers; front pads worn down to 2mm. Installing OEM ceramic replacements.'
    }, mikeCookie);
    assert(mechUpdateRes.status === 200 && mechUpdateRes.data.success, 'Assigned mechanic updates repair progress and technical notes');

    // 9. Test Payment Recording, Transactions, & Balance Validation
    console.log('\n[9/12] Testing Financial Payments & Transaction Integrity...');
    // Initial balance check
    const balCheckRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: `/api/payments/service/${convertedServiceId}/balance`,
      method: 'GET'
    }, null, adminCookie);
    assert(balCheckRes.status === 200 && balCheckRes.data.data.remainingBalance === 3500.00, 'Remaining balance accurately calculated ($3,500.00)');

    // Attempt payment exceeding remaining balance (e.g. $4000)
    const overpayRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/payments',
      method: 'POST'
    }, {
      service_id: convertedServiceId,
      amount: 4000.00,
      payment_method: 'Card'
    }, adminCookie);
    assert(overpayRes.status === 400 && !overpayRes.data.success, 'Overpayment correctly rejected by transaction lock validation');

    // Record valid partial payment ($1500)
    const partialPayRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/payments',
      method: 'POST'
    }, {
      service_id: convertedServiceId,
      amount: 1500.00,
      payment_method: 'UPI',
      payment_date: new Date().toISOString().split('T')[0],
      notes: 'Customer paid partial advance via Google Pay UPI'
    }, adminCookie);
    assert(partialPayRes.status === 201 && partialPayRes.data.remainingBalance === 2000.00, 'Partial payment of $1,500 processed; remaining balance is now $2,000.00');
    const receiptNum = partialPayRes.data.receiptNumber;

    // Settle remaining balance ($2000)
    const fullPayRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/payments',
      method: 'POST'
    }, {
      service_id: convertedServiceId,
      amount: 2000.00,
      payment_method: 'Card',
      payment_date: new Date().toISOString().split('T')[0],
      notes: 'Final balance settled via Credit Card at counter'
    }, adminCookie);
    assert(fullPayRes.status === 201 && fullPayRes.data.remainingBalance === 0.00, 'Final balance settled; remaining balance is exactly $0.00');

    // 10. Test Receipt Generation
    console.log('\n[10/12] Testing Official Receipt & Tax Invoice...');
    const receiptRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: `/api/payments/receipt/${receiptNum}`,
      method: 'GET'
    }, null, adminCookie);
    assert(receiptRes.status === 200 && receiptRes.data.data.receipt_number === receiptNum, 'Official receipt generated with itemized vehicle & client details');

    // 11. Test Dashboard Statistics
    console.log('\n[11/12] Testing Dashboard Statistics Engine...');
    const adminStatsRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/dashboard/stats',
      method: 'GET'
    }, null, adminCookie);
    assert(adminStatsRes.status === 200 && adminStatsRes.data.data.totalServices > 0 && adminStatsRes.data.data.totalRevenue > 0, 'Admin dashboard returns live aggregated statistics and revenue');

    // 12. Test Role-Based Protection & Reports
    console.log('\n[12/12] Testing RBAC Route Protection & Financial Reports...');
    // Customer trying to access Admin-only reports route -> must be 403 Forbidden
    const forbiddenReportRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/reports/collections',
      method: 'GET'
    }, null, customerCookie);
    assert(forbiddenReportRes.status === 403, 'Customer correctly forbidden (403) from accessing admin reports');

    // Admin accessing collections report
    const adminReportRes = await httpRequest({
      hostname: 'localhost',
      port,
      path: '/api/reports/collections',
      method: 'GET'
    }, null, adminCookie);
    assert(adminReportRes.status === 200 && adminReportRes.data.summary.totalCollections > 0, 'Admin receives verified collections report with breakdown');

    console.log('\n====================================================');
    console.log(`TEST SUITE COMPLETED: ${passed} PASSED, ${failed} FAILED`);
    console.log('====================================================\n');

  } catch (err) {
    console.error('Test execution crashed:', err);
    failed++;
  } finally {
    if (server) {
      server.close();
    }
    process.exit(failed > 0 ? 1 : 0);
  }
}

runTests();
