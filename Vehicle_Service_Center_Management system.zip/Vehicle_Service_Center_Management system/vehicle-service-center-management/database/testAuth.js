const mysql = require('mysql2/promise');

async function test() {
  try {
    const conn = await mysql.createConnection({
      host: 'localhost',
      port: 3306,
      user: 'root',
      password: 'niha123'
    });
    console.log('SUCCESS: Successfully connected to local MySQL Server with password "niha123"!');
    const [rows] = await conn.query('SHOW DATABASES;');
    console.log('Databases:', rows.map(r => r.Database));
    await conn.end();
  } catch (err) {
    console.error('Connection error:', err);
  }
}

test();
