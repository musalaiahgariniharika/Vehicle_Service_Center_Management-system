-- =======================================================
-- Vehicle Service Center Management System
-- Database Schema Definition
-- Database: vehicle_service_center
-- =======================================================

CREATE DATABASE IF NOT EXISTS `vehicle_service_center`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `vehicle_service_center`;

-- -------------------------------------------------------
-- Table 1: customers
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(15) NOT NULL,
  `email` VARCHAR(100) UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `address` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_customer_email` (`email`),
  INDEX `idx_customer_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table 2: vehicles
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `vehicles` (
  `vehicle_id` INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT NOT NULL,
  `vehicle_number` VARCHAR(30) NOT NULL UNIQUE,
  `vehicle_model` VARCHAR(100) NOT NULL,
  `vehicle_type` VARCHAR(50) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_vehicle_customer` (`customer_id`),
  INDEX `idx_vehicle_number` (`vehicle_number`),
  CONSTRAINT `fk_vehicles_customer` FOREIGN KEY (`customer_id`)
    REFERENCES `customers` (`customer_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table 3: services
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `services` (
  `service_id` INT AUTO_INCREMENT PRIMARY KEY,
  `vehicle_id` INT NOT NULL,
  `service_type` VARCHAR(100) NOT NULL,
  `service_date` DATE NOT NULL,
  `description` TEXT,
  `service_charge` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(30) NOT NULL DEFAULT 'Received',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_services_vehicle` (`vehicle_id`),
  INDEX `idx_services_status` (`status`),
  INDEX `idx_services_date` (`service_date`),
  CONSTRAINT `fk_services_vehicle` FOREIGN KEY (`vehicle_id`)
    REFERENCES `vehicles` (`vehicle_id`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table 4: payments
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` INT AUTO_INCREMENT PRIMARY KEY,
  `service_id` INT NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `payment_method` VARCHAR(30) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'Paid',
  `receipt_number` VARCHAR(50) NOT NULL UNIQUE,
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_payments_service` (`service_id`),
  INDEX `idx_payments_receipt` (`receipt_number`),
  INDEX `idx_payments_date` (`payment_date`),
  CONSTRAINT `fk_payments_service` FOREIGN KEY (`service_id`)
    REFERENCES `services` (`service_id`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table 5: admins
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `name` VARCHAR(100) NOT NULL DEFAULT 'System Administrator',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_admin_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table 6: mechanics
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `mechanics` (
  `mechanic_id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(15) NOT NULL,
  `email` VARCHAR(100) UNIQUE,
  `specialization` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'Active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_mechanic_status` (`status`),
  INDEX `idx_mechanic_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table 7: appointments
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `appointments` (
  `appointment_id` INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT NOT NULL,
  `vehicle_id` INT NOT NULL,
  `appointment_date` DATE NOT NULL,
  `appointment_time` TIME NOT NULL,
  `service_type` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `status` VARCHAR(30) NOT NULL DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_appointments_customer` (`customer_id`),
  INDEX `idx_appointments_vehicle` (`vehicle_id`),
  INDEX `idx_appointments_date_time` (`appointment_date`, `appointment_time`),
  INDEX `idx_appointments_status` (`status`),
  CONSTRAINT `fk_appointments_customer` FOREIGN KEY (`customer_id`)
    REFERENCES `customers` (`customer_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_appointments_vehicle` FOREIGN KEY (`vehicle_id`)
    REFERENCES `vehicles` (`vehicle_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Table 8: service_assignments
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `service_assignments` (
  `assignment_id` INT AUTO_INCREMENT PRIMARY KEY,
  `service_id` INT NOT NULL,
  `mechanic_id` INT NOT NULL,
  `assigned_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remarks` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_assignments_service` (`service_id`),
  INDEX `idx_assignments_mechanic` (`mechanic_id`),
  CONSTRAINT `fk_assignments_service` FOREIGN KEY (`service_id`)
    REFERENCES `services` (`service_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_assignments_mechanic` FOREIGN KEY (`mechanic_id`)
    REFERENCES `mechanics` (`mechanic_id`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
