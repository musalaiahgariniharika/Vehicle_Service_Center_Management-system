const express = require('express');
const router = express.Router();
const customerController = require('../controllers/customerController');
const { isAuthenticated, requireRole } = require('../middleware/authMiddleware');

router.use(isAuthenticated);

router.get('/', requireRole('admin'), customerController.getAllCustomers);
router.get('/:id', customerController.getCustomerById);
router.post('/', requireRole('admin'), customerController.createCustomer);
router.put('/:id', customerController.updateCustomer);
router.delete('/:id', requireRole('admin'), customerController.deleteCustomer);

module.exports = router;
