const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/paymentController');
const { isAuthenticated, requireRole } = require('../middleware/authMiddleware');

router.use(isAuthenticated);

router.get('/', paymentController.getAllPayments);
router.get('/service/:serviceId/balance', paymentController.getServiceBalance);
router.post('/', requireRole('admin'), paymentController.recordPayment);
router.get('/receipt/:receiptNumber', paymentController.getReceipt);

module.exports = router;
