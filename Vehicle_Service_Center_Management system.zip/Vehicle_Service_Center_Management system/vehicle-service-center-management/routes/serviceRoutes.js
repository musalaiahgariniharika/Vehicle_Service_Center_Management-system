const express = require('express');
const router = express.Router();
const serviceController = require('../controllers/serviceController');
const { isAuthenticated, requireRole } = require('../middleware/authMiddleware');

router.use(isAuthenticated);

router.get('/', serviceController.getAllServices);
router.get('/:id', serviceController.getServiceById);
router.post('/', requireRole('admin'), serviceController.createService);
router.put('/:id', requireRole('admin'), serviceController.updateService);
router.put('/:id/mechanic-update', requireRole('mechanic'), serviceController.mechanicUpdate);
router.delete('/:id', requireRole('admin'), serviceController.deleteService);

module.exports = router;
