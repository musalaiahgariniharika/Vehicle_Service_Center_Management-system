const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');
const { isAuthenticated, requireRole } = require('../middleware/authMiddleware');

router.use(isAuthenticated);
router.use(requireRole('admin'));

router.get('/customers', reportController.getCustomerWiseReport);
router.get('/vehicles', reportController.getVehicleWiseReport);
router.get('/timeline', reportController.getServiceTimelineReport);
router.get('/mechanics', reportController.getMechanicReport);
router.get('/collections', reportController.getPaymentCollectionsReport);
router.get('/pending-payments', reportController.getPendingPaymentsReport);
router.get('/service-types', reportController.getServiceTypeReport);

module.exports = router;
