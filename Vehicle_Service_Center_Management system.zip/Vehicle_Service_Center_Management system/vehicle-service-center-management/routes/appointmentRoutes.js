const express = require('express');
const router = express.Router();
const appointmentController = require('../controllers/appointmentController');
const { isAuthenticated, requireRole } = require('../middleware/authMiddleware');

router.use(isAuthenticated);

router.get('/', appointmentController.getAllAppointments);
router.get('/:id', appointmentController.getAppointmentById);
router.post('/', appointmentController.createAppointment);
router.put('/:id/status', appointmentController.updateStatus);
router.put('/:id/reschedule', appointmentController.reschedule);
router.post('/:id/convert-to-service', requireRole('admin'), appointmentController.convertToService);

module.exports = router;
