const express = require('express');
const router = express.Router();
const mechanicController = require('../controllers/mechanicController');
const { isAuthenticated, requireRole } = require('../middleware/authMiddleware');

router.use(isAuthenticated);

router.get('/', mechanicController.getAllMechanics);
router.get('/:id', mechanicController.getMechanicById);
router.post('/', requireRole('admin'), mechanicController.createMechanic);
router.put('/:id', requireRole('admin'), mechanicController.updateMechanic);
router.delete('/:id', requireRole('admin'), mechanicController.deleteMechanic);
router.post('/assign', requireRole('admin'), mechanicController.assignMechanic);

module.exports = router;
