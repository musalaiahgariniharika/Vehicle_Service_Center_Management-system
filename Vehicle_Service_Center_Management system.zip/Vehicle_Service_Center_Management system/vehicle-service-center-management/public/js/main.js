/**
 * Vehicle Service Center Management System
 * Shared Client-Side Engine
 */

let currentUser = null;

// Initialize session and page state
async function initApp(options = { requireAuth: true, allowedRoles: [] }) {
  try {
    const res = await fetch('/api/auth/me');
    const data = await res.json();

    if (data.success && data.user) {
      currentUser = data.user;
      renderUserUI(currentUser);
      applyRolePermissions(currentUser);

      // If page has role restrictions
      if (options.allowedRoles && options.allowedRoles.length > 0) {
        if (!options.allowedRoles.includes(currentUser.role)) {
          showToast('Access restricted for your account role.', 'danger');
          setTimeout(() => {
            window.location.href = 'dashboard.html';
          }, 1500);
          return null;
        }
      }
      return currentUser;
    } else {
      currentUser = null;
      if (options.requireAuth) {
        window.location.href = 'login.html';
        return null;
      }
    }
  } catch (err) {
    console.error('Session check failed:', err);
    if (options.requireAuth) {
      window.location.href = 'login.html';
    }
  }
  return null;
}

// Render user profile in topbar & sidebar
function renderUserUI(user) {
  const userNameEls = document.querySelectorAll('.user-name-display');
  const userRoleEls = document.querySelectorAll('.user-role-display');
  const userAvatarEls = document.querySelectorAll('.user-avatar-display');

  userNameEls.forEach(el => el.textContent = user.name || user.username || 'User');
  userRoleEls.forEach(el => el.textContent = user.role ? user.role.toUpperCase() : 'USER');
  userAvatarEls.forEach(el => {
    const initial = (user.name || user.username || 'U').charAt(0).toUpperCase();
    el.textContent = initial;
  });
}

// Apply Role-based navigation visibility
function applyRolePermissions(user) {
  const role = user.role;

  // Elements tagged with data-role="..."
  document.querySelectorAll('[data-role]').forEach(el => {
    const allowed = el.getAttribute('data-role').split(',').map(r => r.trim());
    if (allowed.includes(role)) {
      el.style.display = '';
    } else {
      el.style.display = 'none';
    }
  });

  // Specifically adjust titles and labels if needed
  if (role === 'customer') {
    const servicesLink = document.querySelector('a[href="services.html"] span');
    if (servicesLink) servicesLink.textContent = 'My Service History';

    const vehiclesLink = document.querySelector('a[href="vehicles.html"] span');
    if (vehiclesLink) vehiclesLink.textContent = 'My Vehicles';

    const appointmentsLink = document.querySelector('a[href="appointments.html"] span');
    if (appointmentsLink) appointmentsLink.textContent = 'Book & Track Appointments';

    const paymentsLink = document.querySelector('a[href="payments.html"] span');
    if (paymentsLink) paymentsLink.textContent = 'My Invoices & Payments';
  } else if (role === 'mechanic') {
    const servicesLink = document.querySelector('a[href="services.html"] span');
    if (servicesLink) servicesLink.textContent = 'My Assigned Services';
  }
}

// Logout
async function handleLogout() {
  try {
    const res = await fetch('/api/auth/logout', { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      window.location.href = 'login.html';
    } else {
      showToast('Logout failed', 'danger');
    }
  } catch (err) {
    console.error('Logout error:', err);
    window.location.href = 'login.html';
  }
}

// Global Toast Notifications
function showToast(message, type = 'info') {
  let toastContainer = document.getElementById('toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'toast-container';
    toastContainer.style.position = 'fixed';
    toastContainer.style.top = '20px';
    toastContainer.style.right = '20px';
    toastContainer.style.zIndex = '9999';
    toastContainer.style.display = 'flex';
    toastContainer.style.flexDirection = 'column';
    toastContainer.style.gap = '10px';
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement('div');
  const typeColors = {
    success: '#10b981',
    danger: '#ef4444',
    warning: '#f59e0b',
    info: '#2563eb'
  };

  const bg = typeColors[type] || typeColors.info;
  toast.style.background = '#ffffff';
  toast.style.borderLeft = `5px solid ${bg}`;
  toast.style.boxShadow = '0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05)';
  toast.style.borderRadius = '8px';
  toast.style.padding = '12px 18px';
  toast.style.minWidth = '280px';
  toast.style.maxWidth = '420px';
  toast.style.display = 'flex';
  toast.style.alignItems = 'center';
  toast.style.justifyContent = 'space-between';
  toast.style.animation = 'fadeIn 0.3s ease';

  toast.innerHTML = `
    <div style="display:flex; align-items:center; gap:10px;">
      <i class="bi ${type === 'success' ? 'bi-check-circle-fill' : type === 'danger' ? 'bi-exclamation-circle-fill' : 'bi-info-circle-fill'}" style="color:${bg}; font-size:1.2rem;"></i>
      <span style="font-size:0.9rem; font-weight:600; color:#1e293b;">${message}</span>
    </div>
    <button type="button" style="background:none; border:none; color:#94a3b8; font-size:1.1rem; cursor:pointer;" onclick="this.parentElement.remove()">&times;</button>
  `;

  toastContainer.appendChild(toast);
  setTimeout(() => {
    if (toast.parentElement) toast.remove();
  }, 4500);
}

// Currency Formatter
function formatCurrency(amount) {
  const num = parseFloat(amount) || 0;
  return '$' + num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Date Formatter
function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// Generate Status Badge HTML
function getStatusBadge(status) {
  const s = (status || '').toLowerCase().replace(/\s+/g, '-');
  return `<span class="badge-status badge-${s}">${status || 'Unknown'}</span>`;
}

// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('sidebar-toggle');
  const sidebar = document.querySelector('.sidebar');
  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('show');
    });
  }
});
