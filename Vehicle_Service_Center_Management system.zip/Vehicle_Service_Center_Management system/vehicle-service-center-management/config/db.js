require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'niha123',
  database: process.env.DB_NAME || 'vehicle_service_center',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  waitForConnections: true,
  connectionLimit: 15,
  queueLimit: 0,
  dateStrings: true
});

pool.getConnection()
  .then(conn => {
    console.log(' Connected to MySQL database pool (vehicle_service_center)');
    conn.release();
  })
  .catch(err => {
    console.error(' Database connection error:', err.message);
  });

module.exports = pool;
