const db = require('../config/db');
const bcrypt = require('bcryptjs');

const customerController = {
  // Get all customers (with search & filter)
  getAllCustomers: async (req, res) => {
    try {
      const { search } = req.query;
      let query = `
        SELECT c.customer_id, c.name, c.phone, c.email, c.address, c.created_at,
               (SELECT COUNT(*) FROM vehicles v WHERE v.customer_id = c.customer_id) AS total_vehicles,
               (SELECT COUNT(*) FROM services s JOIN vehicles v ON s.vehicle_id = v.vehicle_id WHERE v.customer_id = c.customer_id) AS total_services
        FROM customers c
      `;
      const params = [];

      if (search) {
        const s = `%${search.trim()}%`;
        query += ` WHERE c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ? OR c.address LIKE ?`;
        params.push(s, s, s, s);
      }

      query += ` ORDER BY c.customer_id DESC`;

      const [customers] = await db.query(query, params);
      res.json({ success: true, data: customers });
    } catch (error) {
      console.error('Error fetching customers:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve customers.' });
    }
  },

  // Get customer by ID (with vehicles, appointments, services)
  getCustomerById: async (req, res) => {
    try {
      const customerId = parseInt(req.params.id, 10);
      const user = req.session.user;

      // Role check: customer can only view own profile
      if (user.role === 'customer' && user.id !== customerId) {
        return res.status(403).json({ success: false, message: 'Forbidden. You can only view your own profile.' });
      }

      const [customerRows] = await db.query(
        'SELECT customer_id, name, phone, email, address, created_at FROM customers WHERE customer_id = ?',
        [customerId]
      );

      if (customerRows.length === 0) {
        return res.status(404).json({ success: false, message: 'Customer not found.' });
      }

      const customer = customerRows[0];

      // Fetch customer vehicles
      const [vehicles] = await db.query(
        'SELECT * FROM vehicles WHERE customer_id = ? ORDER BY vehicle_id DESC',
        [customerId]
      );

      // Fetch service history for this customer's vehicles
      const [services] = await db.query(
        `SELECT s.*, v.vehicle_number, v.vehicle_model, v.vehicle_type,
                COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0) AS total_paid,
                (s.service_charge - COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0)) AS remaining_balance
         FROM services s
         JOIN vehicles v ON s.vehicle_id = v.vehicle_id
         WHERE v.customer_id = ?
         ORDER BY s.service_date DESC, s.service_id DESC`,
        [customerId]
      );

      // Fetch appointments
      const [appointments] = await db.query(
        `SELECT a.*, v.vehicle_number, v.vehicle_model 
         FROM appointments a
         JOIN vehicles v ON a.vehicle_id = v.vehicle_id
         WHERE a.customer_id = ?
         ORDER BY a.appointment_date DESC, a.appointment_time DESC`,
        [customerId]
      );

      res.json({
        success: true,
        data: {
          ...customer,
          vehicles,
          services,
          appointments
        }
      });
    } catch (error) {
      console.error('Error fetching customer details:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve customer details.' });
    }
  },

  // Create customer (Admin)
  createCustomer: async (req, res) => {
    try {
      const { name, phone, email, address, password } = req.body;

      if (!name || !phone || !email) {
        return res.status(400).json({ success: false, message: 'Name, phone, and email are required.' });
      }

      const [existing] = await db.query(
        'SELECT customer_id FROM customers WHERE email = ? OR phone = ?',
        [email.trim().toLowerCase(), phone.trim()]
      );

      if (existing.length > 0) {
        return res.status(409).json({ success: false, message: 'Customer with this email or phone already exists.' });
      }

      const rawPassword = password || 'customer123';
      const hashedPassword = await bcrypt.hash(rawPassword, 10);

      const [result] = await db.query(
        'INSERT INTO customers (name, phone, email, password, address) VALUES (?, ?, ?, ?, ?)',
        [name.trim(), phone.trim(), email.trim().toLowerCase(), hashedPassword, (address || '').trim()]
      );

      res.status(201).json({
        success: true,
        message: 'Customer created successfully.',
        customerId: result.insertId
      });
    } catch (error) {
      console.error('Error creating customer:', error);
      res.status(500).json({ success: false, message: 'Failed to create customer.' });
    }
  },

  // Update customer
  updateCustomer: async (req, res) => {
    try {
      const customerId = parseInt(req.params.id, 10);
      const user = req.session.user;

      if (user.role === 'customer' && user.id !== customerId) {
        return res.status(403).json({ success: false, message: 'Forbidden. You can only update your own profile.' });
      }

      const { name, phone, email, address, password } = req.body;

      if (!name || !phone || !email) {
        return res.status(400).json({ success: false, message: 'Name, phone, and email are required.' });
      }

      // Check for email collision
      const [existing] = await db.query(
        'SELECT customer_id FROM customers WHERE (email = ? OR phone = ?) AND customer_id != ?',
        [email.trim().toLowerCase(), phone.trim(), customerId]
      );

      if (existing.length > 0) {
        return res.status(409).json({ success: false, message: 'Email or phone is already taken by another customer.' });
      }

      if (password && password.trim().length >= 6) {
        const hashedPassword = await bcrypt.hash(password.trim(), 10);
        await db.query(
          'UPDATE customers SET name = ?, phone = ?, email = ?, address = ?, password = ? WHERE customer_id = ?',
          [name.trim(), phone.trim(), email.trim().toLowerCase(), (address || '').trim(), hashedPassword, customerId]
        );
      } else {
        await db.query(
          'UPDATE customers SET name = ?, phone = ?, email = ?, address = ? WHERE customer_id = ?',
          [name.trim(), phone.trim(), email.trim().toLowerCase(), (address || '').trim(), customerId]
        );
      }

      // If updating own session, update req.session.user
      if (user.role === 'customer' && user.id === customerId) {
        user.name = name.trim();
        user.email = email.trim().toLowerCase();
        user.phone = phone.trim();
        user.address = (address || '').trim();
      }

      res.json({ success: true, message: 'Customer updated successfully.' });
    } catch (error) {
      console.error('Error updating customer:', error);
      res.status(500).json({ success: false, message: 'Failed to update customer.' });
    }
  },

  // Delete customer safely (Admin only)
  deleteCustomer: async (req, res) => {
    try {
      const customerId = parseInt(req.params.id, 10);

      // Check if there are active services for this customer's vehicles
      const [activeServices] = await db.query(
        `SELECT s.service_id, s.status
         FROM services s
         JOIN vehicles v ON s.vehicle_id = v.vehicle_id
         WHERE v.customer_id = ? AND s.status NOT IN ('Completed', 'Delivered', 'Cancelled')`,
        [customerId]
      );

      if (activeServices.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete customer with active ongoing service records. Please complete or cancel services first.'
        });
      }

      // Check if there are payments associated
      const [payments] = await db.query(
        `SELECT p.payment_id
         FROM payments p
         JOIN services s ON p.service_id = s.service_id
         JOIN vehicles v ON s.vehicle_id = v.vehicle_id
         WHERE v.customer_id = ?`,
        [customerId]
      );

      if (payments.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete customer with historical payment records to maintain financial audit integrity.'
        });
      }

      await db.query('DELETE FROM customers WHERE customer_id = ?', [customerId]);
      res.json({ success: true, message: 'Customer deleted successfully.' });
    } catch (error) {
      console.error('Error deleting customer:', error);
      res.status(500).json({ success: false, message: 'Failed to delete customer.' });
    }
  }
};

module.exports = customerController;
