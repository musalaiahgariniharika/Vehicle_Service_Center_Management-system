const db = require('../config/db');

const vehicleController = {
  // Get vehicles (Admin gets all, customer gets own)
  getAllVehicles: async (req, res) => {
    try {
      const user = req.session.user;
      const { search, type } = req.query;

      let query = `
        SELECT v.vehicle_id, v.vehicle_number, v.vehicle_model, v.vehicle_type, v.created_at,
               c.customer_id, c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email,
               (SELECT COUNT(*) FROM services s WHERE s.vehicle_id = v.vehicle_id) AS total_services
        FROM vehicles v
        JOIN customers c ON v.customer_id = c.customer_id
      `;

      const conditions = [];
      const params = [];

      if (user.role === 'customer') {
        conditions.push('v.customer_id = ?');
        params.push(user.id);
      }

      if (search) {
        conditions.push('(v.vehicle_number LIKE ? OR v.vehicle_model LIKE ? OR c.name LIKE ?)');
        const s = `%${search.trim()}%`;
        params.push(s, s, s);
      }

      if (type) {
        conditions.push('v.vehicle_type = ?');
        params.push(type);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' ORDER BY v.vehicle_id DESC';

      const [vehicles] = await db.query(query, params);
      res.json({ success: true, data: vehicles });
    } catch (error) {
      console.error('Error fetching vehicles:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve vehicles.' });
    }
  },

  // Get single vehicle with owner & service history
  getVehicleById: async (req, res) => {
    try {
      const vehicleId = parseInt(req.params.id, 10);
      const user = req.session.user;

      const [vehicles] = await db.query(
        `SELECT v.*, c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email, c.address AS customer_address
         FROM vehicles v
         JOIN customers c ON v.customer_id = c.customer_id
         WHERE v.vehicle_id = ?`,
        [vehicleId]
      );

      if (vehicles.length === 0) {
        return res.status(404).json({ success: false, message: 'Vehicle not found.' });
      }

      const vehicle = vehicles[0];

      // Customer permission check
      if (user.role === 'customer' && vehicle.customer_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden. You do not own this vehicle.' });
      }

      // Fetch service history
      const [services] = await db.query(
        `SELECT s.*, 
                m.name AS mechanic_name,
                COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0) AS total_paid,
                (s.service_charge - COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0)) AS remaining_balance
         FROM services s
         LEFT JOIN service_assignments sa ON s.service_id = sa.service_id
         LEFT JOIN mechanics m ON sa.mechanic_id = m.mechanic_id
         WHERE s.vehicle_id = ?
         ORDER BY s.service_date DESC, s.service_id DESC`,
        [vehicleId]
      );

      res.json({
        success: true,
        data: {
          ...vehicle,
          services
        }
      });
    } catch (error) {
      console.error('Error fetching vehicle by ID:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve vehicle details.' });
    }
  },

  // Register vehicle
  createVehicle: async (req, res) => {
    try {
      const user = req.session.user;
      let { customer_id, vehicle_number, vehicle_model, vehicle_type } = req.body;

      if (!vehicle_number || !vehicle_model || !vehicle_type) {
        return res.status(400).json({ success: false, message: 'Vehicle number, model, and type are required.' });
      }

      // If customer is creating, enforce customer_id = user.id
      if (user.role === 'customer') {
        customer_id = user.id;
      } else if (!customer_id) {
        return res.status(400).json({ success: false, message: 'Customer ID is required.' });
      }

      // Normalize vehicle number (uppercase, trimmed)
      const cleanNumber = vehicle_number.trim().toUpperCase();

      // Check unique vehicle number
      const [existing] = await db.query(
        'SELECT vehicle_id FROM vehicles WHERE vehicle_number = ?',
        [cleanNumber]
      );

      if (existing.length > 0) {
        return res.status(409).json({ success: false, message: 'A vehicle with this license plate number is already registered.' });
      }

      const [result] = await db.query(
        'INSERT INTO vehicles (customer_id, vehicle_number, vehicle_model, vehicle_type) VALUES (?, ?, ?, ?)',
        [customer_id, cleanNumber, vehicle_model.trim(), vehicle_type.trim()]
      );

      res.status(201).json({
        success: true,
        message: 'Vehicle registered successfully.',
        vehicleId: result.insertId
      });
    } catch (error) {
      console.error('Error creating vehicle:', error);
      res.status(500).json({ success: false, message: 'Failed to register vehicle.' });
    }
  },

  // Update vehicle
  updateVehicle: async (req, res) => {
    try {
      const vehicleId = parseInt(req.params.id, 10);
      const user = req.session.user;
      const { customer_id, vehicle_number, vehicle_model, vehicle_type } = req.body;

      const [existing] = await db.query('SELECT * FROM vehicles WHERE vehicle_id = ?', [vehicleId]);
      if (existing.length === 0) {
        return res.status(404).json({ success: false, message: 'Vehicle not found.' });
      }

      if (user.role === 'customer' && existing[0].customer_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden. You do not own this vehicle.' });
      }

      const cleanNumber = vehicle_number.trim().toUpperCase();

      // Check duplicate number with other vehicles
      const [duplicate] = await db.query(
        'SELECT vehicle_id FROM vehicles WHERE vehicle_number = ? AND vehicle_id != ?',
        [cleanNumber, vehicleId]
      );

      if (duplicate.length > 0) {
        return res.status(409).json({ success: false, message: 'Vehicle number already belongs to another vehicle.' });
      }

      const targetCustomerId = (user.role === 'admin' && customer_id) ? customer_id : existing[0].customer_id;

      await db.query(
        'UPDATE vehicles SET customer_id = ?, vehicle_number = ?, vehicle_model = ?, vehicle_type = ? WHERE vehicle_id = ?',
        [targetCustomerId, cleanNumber, vehicle_model.trim(), vehicle_type.trim(), vehicleId]
      );

      res.json({ success: true, message: 'Vehicle updated successfully.' });
    } catch (error) {
      console.error('Error updating vehicle:', error);
      res.status(500).json({ success: false, message: 'Failed to update vehicle.' });
    }
  },

  // Delete vehicle
  deleteVehicle: async (req, res) => {
    try {
      const vehicleId = parseInt(req.params.id, 10);
      const user = req.session.user;

      const [vehicles] = await db.query('SELECT * FROM vehicles WHERE vehicle_id = ?', [vehicleId]);
      if (vehicles.length === 0) {
        return res.status(404).json({ success: false, message: 'Vehicle not found.' });
      }

      if (user.role === 'customer' && vehicles[0].customer_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden.' });
      }

      // Check if active services exist
      const [services] = await db.query(
        `SELECT service_id, status FROM services WHERE vehicle_id = ? AND status NOT IN ('Completed', 'Delivered', 'Cancelled')`,
        [vehicleId]
      );

      if (services.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete vehicle with ongoing service records.'
        });
      }

      // Check if payment history exists
      const [payments] = await db.query(
        `SELECT p.payment_id FROM payments p JOIN services s ON p.service_id = s.service_id WHERE s.vehicle_id = ?`,
        [vehicleId]
      );

      if (payments.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete vehicle with historical payment invoices.'
        });
      }

      await db.query('DELETE FROM vehicles WHERE vehicle_id = ?', [vehicleId]);
      res.json({ success: true, message: 'Vehicle deleted successfully.' });
    } catch (error) {
      console.error('Error deleting vehicle:', error);
      res.status(500).json({ success: false, message: 'Failed to delete vehicle.' });
    }
  }
};

module.exports = vehicleController;
