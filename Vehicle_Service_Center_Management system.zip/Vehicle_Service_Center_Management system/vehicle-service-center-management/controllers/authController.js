const db = require('../config/db');
const bcrypt = require('bcryptjs');

const authController = {
  // Login handler
  login: async (req, res) => {
    try {
      const { usernameOrEmail, password, role } = req.body;

      if (!usernameOrEmail || !password) {
        return res.status(400).json({ success: false, message: 'Please provide credentials.' });
      }

      const identifier = usernameOrEmail.trim();

      // 1. Admin login
      if (role === 'admin' || !role) {
        const [admins] = await db.query(
          'SELECT * FROM admins WHERE username = ? OR username = ?',
          [identifier, identifier.toLowerCase()]
        );

        if (admins.length > 0) {
          const admin = admins[0];
          const isMatch = await bcrypt.compare(password, admin.password);
          if (isMatch) {
            req.session.user = {
              id: admin.admin_id,
              username: admin.username,
              name: admin.name,
              role: 'admin'
            };
            return res.json({
              success: true,
              message: 'Admin login successful',
              user: req.session.user
            });
          } else if (role === 'admin') {
            return res.status(401).json({ success: false, message: 'Invalid admin credentials.' });
          }
        } else if (role === 'admin') {
          return res.status(401).json({ success: false, message: 'Admin account not found.' });
        }
      }

      // 2. Mechanic login
      if (role === 'mechanic' || !role) {
        const [mechanics] = await db.query(
          'SELECT * FROM mechanics WHERE email = ? OR phone = ?',
          [identifier.toLowerCase(), identifier]
        );

        if (mechanics.length > 0) {
          const mechanic = mechanics[0];
          if (mechanic.status === 'Inactive') {
            return res.status(403).json({ success: false, message: 'Mechanic account is inactive. Please contact admin.' });
          }
          const isMatch = await bcrypt.compare(password, mechanic.password);
          if (isMatch) {
            req.session.user = {
              id: mechanic.mechanic_id,
              name: mechanic.name,
              email: mechanic.email,
              phone: mechanic.phone,
              specialization: mechanic.specialization,
              role: 'mechanic'
            };
            return res.json({
              success: true,
              message: 'Mechanic login successful',
              user: req.session.user
            });
          } else if (role === 'mechanic') {
            return res.status(401).json({ success: false, message: 'Invalid mechanic credentials.' });
          }
        } else if (role === 'mechanic') {
          return res.status(401).json({ success: false, message: 'Mechanic account not found.' });
        }
      }

      // 3. Customer login
      if (role === 'customer' || !role) {
        const [customers] = await db.query(
          'SELECT * FROM customers WHERE email = ? OR phone = ?',
          [identifier.toLowerCase(), identifier]
        );

        if (customers.length > 0) {
          const customer = customers[0];
          const isMatch = await bcrypt.compare(password, customer.password);
          if (isMatch) {
            req.session.user = {
              id: customer.customer_id,
              name: customer.name,
              email: customer.email,
              phone: customer.phone,
              address: customer.address,
              role: 'customer'
            };
            return res.json({
              success: true,
              message: 'Customer login successful',
              user: req.session.user
            });
          } else {
            return res.status(401).json({ success: false, message: 'Invalid password.' });
          }
        } else if (role === 'customer') {
          return res.status(401).json({ success: false, message: 'Customer account not found.' });
        }
      }

      return res.status(401).json({ success: false, message: 'Invalid credentials or user not found.' });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ success: false, message: 'Server error during login.' });
    }
  },

  // Customer self-registration
  register: async (req, res) => {
    try {
      const { name, phone, email, password, address } = req.body;

      if (!name || !phone || !email || !password) {
        return res.status(400).json({ success: false, message: 'Name, phone, email, and password are required.' });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ success: false, message: 'Please provide a valid email address.' });
      }

      if (password.length < 6) {
        return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
      }

      // Check if email or phone already exists
      const [existing] = await db.query(
        'SELECT customer_id FROM customers WHERE email = ? OR phone = ?',
        [email.trim().toLowerCase(), phone.trim()]
      );

      if (existing.length > 0) {
        return res.status(409).json({ success: false, message: 'Email or phone number is already registered.' });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const [result] = await db.query(
        'INSERT INTO customers (name, phone, email, password, address) VALUES (?, ?, ?, ?, ?)',
        [name.trim(), phone.trim(), email.trim().toLowerCase(), hashedPassword, (address || '').trim()]
      );

      // Auto login after registration
      req.session.user = {
        id: result.insertId,
        name: name.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        address: (address || '').trim(),
        role: 'customer'
      };

      res.status(201).json({
        success: true,
        message: 'Account registered successfully!',
        user: req.session.user
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ success: false, message: 'Server error during registration.' });
    }
  },

  // Get current logged in user session
  getMe: async (req, res) => {
    if (req.session && req.session.user) {
      return res.json({ success: true, user: req.session.user });
    }
    return res.json({ success: false, user: null });
  },

  // Logout
  logout: async (req, res) => {
    req.session.destroy(err => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Could not log out.' });
      }
      res.clearCookie('connect.sid');
      return res.json({ success: true, message: 'Logged out successfully.' });
    });
  }
};

module.exports = authController;
