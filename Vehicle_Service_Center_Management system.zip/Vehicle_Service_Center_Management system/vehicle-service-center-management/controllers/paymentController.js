const db = require('../config/db');

const paymentController = {
  // Get all payments (Admin gets all, Customer gets own)
  getAllPayments: async (req, res) => {
    try {
      const user = req.session.user;
      const { status, payment_method, startDate, endDate, search } = req.query;

      let query = `
        SELECT p.*, 
               s.service_type, s.service_charge, s.service_date,
               v.vehicle_number, v.vehicle_model,
               c.customer_id, c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email
        FROM payments p
        JOIN services s ON p.service_id = s.service_id
        JOIN vehicles v ON s.vehicle_id = v.vehicle_id
        JOIN customers c ON v.customer_id = c.customer_id
      `;

      const conditions = [];
      const params = [];

      if (user.role === 'customer') {
        conditions.push('c.customer_id = ?');
        params.push(user.id);
      }

      if (status) {
        conditions.push('p.status = ?');
        params.push(status);
      }

      if (payment_method) {
        conditions.push('p.payment_method = ?');
        params.push(payment_method);
      }

      if (startDate) {
        conditions.push('p.payment_date >= ?');
        params.push(startDate);
      }

      if (endDate) {
        conditions.push('p.payment_date <= ?');
        params.push(endDate);
      }

      if (search) {
        conditions.push('(p.receipt_number LIKE ? OR c.name LIKE ? OR v.vehicle_number LIKE ?)');
        const s = `%${search.trim()}%`;
        params.push(s, s, s);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' ORDER BY p.payment_date DESC, p.payment_id DESC';

      const [payments] = await db.query(query, params);
      res.json({ success: true, data: payments });
    } catch (error) {
      console.error('Error fetching payments:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve payments.' });
    }
  },

  // Get service balance & payment summary
  getServiceBalance: async (req, res) => {
    try {
      const serviceId = parseInt(req.params.serviceId, 10);
      const user = req.session.user;

      const [services] = await db.query(
        `SELECT s.service_id, s.service_type, s.service_charge, s.status AS service_status,
                v.vehicle_number, v.vehicle_model,
                c.customer_id, c.name AS customer_name
         FROM services s
         JOIN vehicles v ON s.vehicle_id = v.vehicle_id
         JOIN customers c ON v.customer_id = c.customer_id
         WHERE s.service_id = ?`,
        [serviceId]
      );

      if (services.length === 0) {
        return res.status(404).json({ success: false, message: 'Service record not found.' });
      }

      const service = services[0];
      if (user.role === 'customer' && service.customer_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden.' });
      }

      const [payments] = await db.query(
        'SELECT COALESCE(SUM(amount), 0) AS total_paid FROM payments WHERE service_id = ? AND status = "Paid"',
        [serviceId]
      );

      const totalCharge = parseFloat(service.service_charge) || 0.00;
      const totalPaid = parseFloat(payments[0].total_paid) || 0.00;
      const remainingBalance = Math.max(0, +(totalCharge - totalPaid).toFixed(2));

      res.json({
        success: true,
        data: {
          serviceId,
          serviceType: service.service_type,
          serviceCharge: totalCharge,
          totalPaid,
          remainingBalance,
          customerName: service.customer_name,
          vehicleNumber: service.vehicle_number
        }
      });
    } catch (error) {
      console.error('Error checking balance:', error);
      res.status(500).json({ success: false, message: 'Failed to calculate balance.' });
    }
  },

  // Record payment using MySQL Transaction
  recordPayment: async (req, res) => {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();

      const { service_id, amount, payment_date, payment_method, notes } = req.body;

      if (!service_id || !amount || !payment_method) {
        await connection.rollback();
        return res.status(400).json({ success: false, message: 'Service, amount, and payment method are required.' });
      }

      const payAmount = parseFloat(amount);
      if (isNaN(payAmount) || payAmount <= 0) {
        await connection.rollback();
        return res.status(400).json({ success: false, message: 'Payment amount must be a positive number.' });
      }

      const validMethods = ['Cash', 'Card', 'UPI', 'Bank Transfer'];
      if (!validMethods.includes(payment_method)) {
        await connection.rollback();
        return res.status(400).json({ success: false, message: `Invalid payment method. Allowed: ${validMethods.join(', ')}` });
      }

      // Lock service row for update to prevent concurrent payment race conditions
      const [serviceRows] = await connection.query(
        'SELECT service_id, service_charge, status FROM services WHERE service_id = ? FOR UPDATE',
        [service_id]
      );

      if (serviceRows.length === 0) {
        await connection.rollback();
        return res.status(404).json({ success: false, message: 'Service not found.' });
      }

      const service = serviceRows[0];
      const serviceCharge = parseFloat(service.service_charge) || 0.00;

      // Lock payments sum
      const [paidRows] = await connection.query(
        'SELECT COALESCE(SUM(amount), 0) AS total_paid FROM payments WHERE service_id = ? AND status = "Paid" FOR UPDATE',
        [service_id]
      );

      const alreadyPaid = parseFloat(paidRows[0].total_paid) || 0.00;
      const remainingBalance = +(serviceCharge - alreadyPaid).toFixed(2);

      if (remainingBalance <= 0) {
        await connection.rollback();
        return res.status(400).json({ success: false, message: 'This service is already fully paid. Outstanding balance is 0.00.' });
      }

      if (payAmount > remainingBalance) {
        await connection.rollback();
        return res.status(400).json({
          success: false,
          message: `Payment amount (\$${payAmount.toFixed(2)}) exceeds remaining balance of \$${remainingBalance.toFixed(2)}.`
        });
      }

      // Generate unique receipt number: REC-YYYYMMDD-Random(4)
      const datePart = (payment_date || new Date().toISOString().split('T')[0]).replace(/-/g, '');
      const randomPart = Math.floor(1000 + Math.random() * 9000);
      const receiptNumber = `REC-${datePart}-${randomPart}`;

      const pDate = payment_date || new Date().toISOString().split('T')[0];

      const [payResult] = await connection.query(
        `INSERT INTO payments (service_id, amount, payment_date, payment_method, status, receipt_number, notes)
         VALUES (?, ?, ?, ?, 'Paid', ?, ?)`,
        [service_id, payAmount, pDate, payment_method, receiptNumber, (notes || 'Manual/Demo payment recorded').trim()]
      );

      // Check new remaining balance
      const newRemaining = +(remainingBalance - payAmount).toFixed(2);

      await connection.commit();

      res.status(201).json({
        success: true,
        message: 'Payment recorded successfully!',
        receiptNumber,
        paymentId: payResult.insertId,
        amountPaid: payAmount,
        remainingBalance: newRemaining
      });
    } catch (error) {
      await connection.rollback();
      console.error('Payment recording error:', error);
      res.status(500).json({ success: false, message: 'Transaction failed. Payment could not be recorded.' });
    } finally {
      connection.release();
    }
  },

  // Get printable receipt
  getReceipt: async (req, res) => {
    try {
      const receiptNumber = req.params.receiptNumber;
      const user = req.session.user;

      const [receiptRows] = await db.query(
        `SELECT p.*,
                s.service_type, s.service_date, s.service_charge, s.description AS service_description, s.status AS service_status,
                v.vehicle_number, v.vehicle_model, v.vehicle_type,
                c.customer_id, c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email, c.address AS customer_address,
                m.name AS mechanic_name
         FROM payments p
         JOIN services s ON p.service_id = s.service_id
         JOIN vehicles v ON s.vehicle_id = v.vehicle_id
         JOIN customers c ON v.customer_id = c.customer_id
         LEFT JOIN service_assignments sa ON s.service_id = sa.service_id
         LEFT JOIN mechanics m ON sa.mechanic_id = m.mechanic_id
         WHERE p.receipt_number = ?`,
        [receiptNumber]
      );

      if (receiptRows.length === 0) {
        return res.status(404).json({ success: false, message: 'Receipt not found.' });
      }

      const receipt = receiptRows[0];

      if (user.role === 'customer' && receipt.customer_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden.' });
      }

      // Also get all payments for this service to calculate cumulative payment summary
      const [allServicePayments] = await db.query(
        'SELECT payment_id, amount, payment_date, payment_method, receipt_number FROM payments WHERE service_id = ? AND status = "Paid" ORDER BY payment_id ASC',
        [receipt.service_id]
      );

      const totalPaidForService = allServicePayments.reduce((acc, curr) => acc + parseFloat(curr.amount), 0);
      const remainingBalance = Math.max(0, +(parseFloat(receipt.service_charge) - totalPaidForService).toFixed(2));

      res.json({
        success: true,
        data: {
          ...receipt,
          allServicePayments,
          totalPaidForService,
          remainingBalance
        }
      });
    } catch (error) {
      console.error('Error fetching receipt:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve receipt.' });
    }
  }
};

module.exports = paymentController;
