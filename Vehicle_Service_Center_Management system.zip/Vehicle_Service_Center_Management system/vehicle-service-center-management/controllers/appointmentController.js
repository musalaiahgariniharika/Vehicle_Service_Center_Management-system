const db = require('../config/db');

const appointmentController = {
  // Get all appointments
  getAllAppointments: async (req, res) => {
    try {
      const user = req.session.user;
      const { status, date, search } = req.query;

      let query = `
        SELECT a.*, 
               c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email,
               v.vehicle_number, v.vehicle_model, v.vehicle_type
        FROM appointments a
        JOIN customers c ON a.customer_id = c.customer_id
        JOIN vehicles v ON a.vehicle_id = v.vehicle_id
      `;

      const conditions = [];
      const params = [];

      if (user.role === 'customer') {
        conditions.push('a.customer_id = ?');
        params.push(user.id);
      }

      if (status) {
        conditions.push('a.status = ?');
        params.push(status);
      }

      if (date) {
        conditions.push('a.appointment_date = ?');
        params.push(date);
      }

      if (search) {
        conditions.push('(c.name LIKE ? OR v.vehicle_number LIKE ? OR a.service_type LIKE ?)');
        const s = `%${search.trim()}%`;
        params.push(s, s, s);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' ORDER BY a.appointment_date DESC, a.appointment_time DESC';

      const [appointments] = await db.query(query, params);
      res.json({ success: true, data: appointments });
    } catch (error) {
      console.error('Error fetching appointments:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve appointments.' });
    }
  },

  // Get single appointment
  getAppointmentById: async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id, 10);
      const user = req.session.user;

      const [rows] = await db.query(
        `SELECT a.*, 
                c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email,
                v.vehicle_number, v.vehicle_model, v.vehicle_type
         FROM appointments a
         JOIN customers c ON a.customer_id = c.customer_id
         JOIN vehicles v ON a.vehicle_id = v.vehicle_id
         WHERE a.appointment_id = ?`,
        [appointmentId]
      );

      if (rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Appointment not found.' });
      }

      const appointment = rows[0];
      if (user.role === 'customer' && appointment.customer_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden.' });
      }

      res.json({ success: true, data: appointment });
    } catch (error) {
      console.error('Error fetching appointment:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve appointment.' });
    }
  },

  // Create appointment request
  createAppointment: async (req, res) => {
    try {
      const user = req.session.user;
      let { customer_id, vehicle_id, appointment_date, appointment_time, service_type, description } = req.body;

      if (!vehicle_id || !appointment_date || !appointment_time || !service_type) {
        return res.status(400).json({ success: false, message: 'Vehicle, date, time, and service type are required.' });
      }

      if (user.role === 'customer') {
        customer_id = user.id;
      } else if (!customer_id) {
        // Find customer owning this vehicle
        const [veh] = await db.query('SELECT customer_id FROM vehicles WHERE vehicle_id = ?', [vehicle_id]);
        if (veh.length === 0) {
          return res.status(404).json({ success: false, message: 'Vehicle not found.' });
        }
        customer_id = veh[0].customer_id;
      }

      // Verify that vehicle belongs to customer
      const [vehicleCheck] = await db.query(
        'SELECT vehicle_id FROM vehicles WHERE vehicle_id = ? AND customer_id = ?',
        [vehicle_id, customer_id]
      );
      if (vehicleCheck.length === 0) {
        return res.status(400).json({ success: false, message: 'Selected vehicle does not belong to this customer.' });
      }

      // Prevent past dates
      const appDate = new Date(`${appointment_date}T${appointment_time}`);
      const now = new Date();
      // Allow today's date if later today, but strictly disallow past dates
      const todayDateStr = new Date().toISOString().split('T')[0];
      if (appointment_date < todayDateStr) {
        return res.status(400).json({ success: false, message: 'Cannot book an appointment for a past date.' });
      }

      // Check conflict: same vehicle on the same date with active status
      const [vehicleConflict] = await db.query(
        `SELECT appointment_id FROM appointments 
         WHERE vehicle_id = ? AND appointment_date = ? AND status IN ('Pending', 'Approved')`,
        [vehicle_id, appointment_date]
      );

      if (vehicleConflict.length > 0) {
        return res.status(409).json({
          success: false,
          message: 'An active appointment already exists for this vehicle on this date.'
        });
      }

      // Insert appointment
      const [result] = await db.query(
        `INSERT INTO appointments (customer_id, vehicle_id, appointment_date, appointment_time, service_type, description, status)
         VALUES (?, ?, ?, ?, ?, ?, 'Pending')`,
        [customer_id, vehicle_id, appointment_date, appointment_time, service_type.trim(), (description || '').trim()]
      );

      res.status(201).json({
        success: true,
        message: 'Appointment request submitted successfully.',
        appointmentId: result.insertId
      });
    } catch (error) {
      console.error('Error creating appointment:', error);
      res.status(500).json({ success: false, message: 'Failed to submit appointment.' });
    }
  },

  // Update appointment status (Admin or Customer cancel)
  updateStatus: async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id, 10);
      const user = req.session.user;
      const { status } = req.body;

      const validStatuses = ['Pending', 'Approved', 'Rejected', 'Cancelled', 'Completed'];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid appointment status.' });
      }

      const [existing] = await db.query('SELECT * FROM appointments WHERE appointment_id = ?', [appointmentId]);
      if (existing.length === 0) {
        return res.status(404).json({ success: false, message: 'Appointment not found.' });
      }

      // Customer can only cancel their own Pending/Approved appointment
      if (user.role === 'customer') {
        if (existing[0].customer_id !== user.id) {
          return res.status(403).json({ success: false, message: 'Forbidden.' });
        }
        if (status !== 'Cancelled') {
          return res.status(403).json({ success: false, message: 'Customers can only cancel appointments.' });
        }
        if (['Completed', 'Cancelled', 'Rejected'].includes(existing[0].status)) {
          return res.status(400).json({ success: false, message: `Cannot cancel an already ${existing[0].status} appointment.` });
        }
      }

      await db.query('UPDATE appointments SET status = ? WHERE appointment_id = ?', [status, appointmentId]);

      res.json({ success: true, message: `Appointment status updated to ${status}.` });
    } catch (error) {
      console.error('Error updating appointment status:', error);
      res.status(500).json({ success: false, message: 'Failed to update status.' });
    }
  },

  // Reschedule appointment (Admin or Customer)
  reschedule: async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id, 10);
      const user = req.session.user;
      const { appointment_date, appointment_time } = req.body;

      if (!appointment_date || !appointment_time) {
        return res.status(400).json({ success: false, message: 'Date and time are required to reschedule.' });
      }

      const todayDateStr = new Date().toISOString().split('T')[0];
      if (appointment_date < todayDateStr) {
        return res.status(400).json({ success: false, message: 'Cannot reschedule to a past date.' });
      }

      const [existing] = await db.query('SELECT * FROM appointments WHERE appointment_id = ?', [appointmentId]);
      if (existing.length === 0) {
        return res.status(404).json({ success: false, message: 'Appointment not found.' });
      }

      if (user.role === 'customer' && existing[0].customer_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden.' });
      }

      await db.query(
        'UPDATE appointments SET appointment_date = ?, appointment_time = ? WHERE appointment_id = ?',
        [appointment_date, appointment_time, appointmentId]
      );

      res.json({ success: true, message: 'Appointment rescheduled successfully.' });
    } catch (error) {
      console.error('Error rescheduling appointment:', error);
      res.status(500).json({ success: false, message: 'Failed to reschedule appointment.' });
    }
  },

  // Convert approved appointment into a service record (Admin only)
  convertToService: async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id, 10);
      const { service_charge, description, mechanic_id } = req.body;

      const [appointments] = await db.query('SELECT * FROM appointments WHERE appointment_id = ?', [appointmentId]);
      if (appointments.length === 0) {
        return res.status(404).json({ success: false, message: 'Appointment not found.' });
      }

      const app = appointments[0];

      // Insert service record
      const serviceDate = app.appointment_date;
      const serviceType = app.service_type;
      const serviceDesc = description || app.description || 'Converted from appointment';
      const charge = parseFloat(service_charge) || 0.00;

      const [serviceResult] = await db.query(
        `INSERT INTO services (vehicle_id, service_type, service_date, description, service_charge, status)
         VALUES (?, ?, ?, ?, ?, 'Received')`,
        [app.vehicle_id, serviceType, serviceDate, serviceDesc, charge]
      );

      const serviceId = serviceResult.insertId;

      // Assign mechanic if provided
      if (mechanic_id) {
        await db.query(
          `INSERT INTO service_assignments (service_id, mechanic_id, remarks)
           VALUES (?, ?, ?)`,
          [serviceId, mechanic_id, 'Assigned upon appointment conversion.']
        );
      }

      // Mark appointment as Completed
      await db.query('UPDATE appointments SET status = "Completed" WHERE appointment_id = ?', [appointmentId]);

      res.status(201).json({
        success: true,
        message: 'Appointment successfully converted to service record!',
        serviceId
      });
    } catch (error) {
      console.error('Error converting appointment to service:', error);
      res.status(500).json({ success: false, message: 'Failed to convert appointment to service.' });
    }
  }
};

module.exports = appointmentController;
