const db = require('../config/db');
const bcrypt = require('bcryptjs');

const mechanicController = {
  // Get all mechanics
  getAllMechanics: async (req, res) => {
    try {
      const { search, status } = req.query;

      let query = `
        SELECT m.mechanic_id, m.name, m.phone, m.email, m.specialization, m.status, m.created_at,
               COUNT(sa.assignment_id) AS total_assignments,
               SUM(CASE WHEN s.status IN ('Received', 'Inspection', 'In Progress', 'Waiting for Parts') THEN 1 ELSE 0 END) AS active_jobs,
               SUM(CASE WHEN s.status IN ('Completed', 'Delivered') THEN 1 ELSE 0 END) AS completed_jobs
        FROM mechanics m
        LEFT JOIN service_assignments sa ON m.mechanic_id = sa.mechanic_id
        LEFT JOIN services s ON sa.service_id = s.service_id
      `;

      const conditions = [];
      const params = [];

      if (status) {
        conditions.push('m.status = ?');
        params.push(status);
      }

      if (search) {
        conditions.push('(m.name LIKE ? OR m.specialization LIKE ? OR m.phone LIKE ? OR m.email LIKE ?)');
        const s = `%${search.trim()}%`;
        params.push(s, s, s, s);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' GROUP BY m.mechanic_id ORDER BY m.mechanic_id ASC';

      const [mechanics] = await db.query(query, params);
      res.json({ success: true, data: mechanics });
    } catch (error) {
      console.error('Error fetching mechanics:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve mechanics.' });
    }
  },

  // Get mechanic by ID + their assigned services
  getMechanicById: async (req, res) => {
    try {
      const mechanicId = parseInt(req.params.id, 10);

      const [mechanics] = await db.query(
        'SELECT mechanic_id, name, phone, email, specialization, status, created_at FROM mechanics WHERE mechanic_id = ?',
        [mechanicId]
      );

      if (mechanics.length === 0) {
        return res.status(404).json({ success: false, message: 'Mechanic not found.' });
      }

      const mechanic = mechanics[0];

      // Assigned services
      const [assignments] = await db.query(
        `SELECT sa.*, s.service_type, s.service_date, s.status AS service_status, s.description AS service_description,
                v.vehicle_number, v.vehicle_model, v.vehicle_type,
                c.name AS customer_name, c.phone AS customer_phone
         FROM service_assignments sa
         JOIN services s ON sa.service_id = s.service_id
         JOIN vehicles v ON s.vehicle_id = v.vehicle_id
         JOIN customers c ON v.customer_id = c.customer_id
         WHERE sa.mechanic_id = ?
         ORDER BY sa.assigned_date DESC`,
        [mechanicId]
      );

      res.json({
        success: true,
        data: {
          ...mechanic,
          assignments
        }
      });
    } catch (error) {
      console.error('Error fetching mechanic by ID:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve mechanic details.' });
    }
  },

  // Create mechanic (Admin only)
  createMechanic: async (req, res) => {
    try {
      const { name, phone, email, specialization, password, status } = req.body;

      if (!name || !phone || !specialization) {
        return res.status(400).json({ success: false, message: 'Name, phone, and specialization are required.' });
      }

      if (email) {
        const [existing] = await db.query('SELECT mechanic_id FROM mechanics WHERE email = ?', [email.trim().toLowerCase()]);
        if (existing.length > 0) {
          return res.status(409).json({ success: false, message: 'A mechanic with this email already exists.' });
        }
      }

      const rawPassword = password || 'mechanic123';
      const hashedPassword = await bcrypt.hash(rawPassword, 10);
      const mechStatus = status || 'Active';

      const [result] = await db.query(
        `INSERT INTO mechanics (name, phone, email, specialization, password, status)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [name.trim(), phone.trim(), email ? email.trim().toLowerCase() : null, specialization.trim(), hashedPassword, mechStatus]
      );

      res.status(201).json({
        success: true,
        message: 'Mechanic created successfully.',
        mechanicId: result.insertId
      });
    } catch (error) {
      console.error('Error creating mechanic:', error);
      res.status(500).json({ success: false, message: 'Failed to create mechanic.' });
    }
  },

  // Update mechanic
  updateMechanic: async (req, res) => {
    try {
      const mechanicId = parseInt(req.params.id, 10);
      const { name, phone, email, specialization, password, status } = req.body;

      if (!name || !phone || !specialization) {
        return res.status(400).json({ success: false, message: 'Name, phone, and specialization are required.' });
      }

      if (email) {
        const [existing] = await db.query(
          'SELECT mechanic_id FROM mechanics WHERE email = ? AND mechanic_id != ?',
          [email.trim().toLowerCase(), mechanicId]
        );
        if (existing.length > 0) {
          return res.status(409).json({ success: false, message: 'Email is already taken by another mechanic.' });
        }
      }

      if (password && password.trim().length >= 6) {
        const hashedPassword = await bcrypt.hash(password.trim(), 10);
        await db.query(
          `UPDATE mechanics 
           SET name = ?, phone = ?, email = ?, specialization = ?, password = ?, status = ?
           WHERE mechanic_id = ?`,
          [name.trim(), phone.trim(), email ? email.trim().toLowerCase() : null, specialization.trim(), hashedPassword, status || 'Active', mechanicId]
        );
      } else {
        await db.query(
          `UPDATE mechanics 
           SET name = ?, phone = ?, email = ?, specialization = ?, status = ?
           WHERE mechanic_id = ?`,
          [name.trim(), phone.trim(), email ? email.trim().toLowerCase() : null, specialization.trim(), status || 'Active', mechanicId]
        );
      }

      res.json({ success: true, message: 'Mechanic updated successfully.' });
    } catch (error) {
      console.error('Error updating mechanic:', error);
      res.status(500).json({ success: false, message: 'Failed to update mechanic.' });
    }
  },

  // Deactivate or safe delete mechanic
  deleteMechanic: async (req, res) => {
    try {
      const mechanicId = parseInt(req.params.id, 10);

      // Check if active services assigned
      const [activeAssignments] = await db.query(
        `SELECT sa.assignment_id 
         FROM service_assignments sa
         JOIN services s ON sa.service_id = s.service_id
         WHERE sa.mechanic_id = ? AND s.status NOT IN ('Completed', 'Delivered', 'Cancelled')`,
        [mechanicId]
      );

      if (activeAssignments.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete or deactivate mechanic with active assigned service jobs. Reassign the jobs first.'
        });
      }

      // Safe option: deactivate rather than hard delete to preserve historical logs
      await db.query('UPDATE mechanics SET status = "Inactive" WHERE mechanic_id = ?', [mechanicId]);
      res.json({ success: true, message: 'Mechanic deactivated successfully.' });
    } catch (error) {
      console.error('Error deleting mechanic:', error);
      res.status(500).json({ success: false, message: 'Failed to deactivate mechanic.' });
    }
  },

  // Assign mechanic to a service
  assignMechanic: async (req, res) => {
    try {
      const { service_id, mechanic_id, remarks } = req.body;

      if (!service_id || !mechanic_id) {
        return res.status(400).json({ success: false, message: 'Service ID and Mechanic ID are required.' });
      }

      const [existing] = await db.query('SELECT assignment_id FROM service_assignments WHERE service_id = ?', [service_id]);

      if (existing.length > 0) {
        await db.query(
          'UPDATE service_assignments SET mechanic_id = ?, remarks = ?, assigned_date = NOW() WHERE service_id = ?',
          [mechanic_id, remarks || 'Reassigned', service_id]
        );
      } else {
        await db.query(
          'INSERT INTO service_assignments (service_id, mechanic_id, remarks) VALUES (?, ?, ?)',
          [service_id, mechanic_id, remarks || 'Initial assignment']
        );
      }

      res.json({ success: true, message: 'Mechanic successfully assigned to service.' });
    } catch (error) {
      console.error('Error assigning mechanic:', error);
      res.status(500).json({ success: false, message: 'Failed to assign mechanic.' });
    }
  }
};

module.exports = mechanicController;
