const db = require('../config/db');

const validStatuses = [
  'Received',
  'Inspection',
  'In Progress',
  'Waiting for Parts',
  'Completed',
  'Delivered',
  'Cancelled'
];

const serviceController = {
  // Get all services with filters & role scoping
  getAllServices: async (req, res) => {
    try {
      const user = req.session.user;
      const { status, search, startDate, endDate } = req.query;

      let query = `
        SELECT s.service_id, s.service_type, s.service_date, s.description, 
               s.service_charge, s.status, s.created_at, s.updated_at,
               v.vehicle_id, v.vehicle_number, v.vehicle_model, v.vehicle_type,
               c.customer_id, c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email,
               m.mechanic_id, m.name AS mechanic_name, m.specialization AS mechanic_specialization,
               sa.assignment_id, sa.remarks AS mechanic_remarks, sa.assigned_date,
               COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0) AS total_paid,
               (s.service_charge - COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0)) AS remaining_balance
        FROM services s
        JOIN vehicles v ON s.vehicle_id = v.vehicle_id
        JOIN customers c ON v.customer_id = c.customer_id
        LEFT JOIN service_assignments sa ON s.service_id = sa.service_id
        LEFT JOIN mechanics m ON sa.mechanic_id = m.mechanic_id
      `;

      const conditions = [];
      const params = [];

      // Role filter
      if (user.role === 'customer') {
        conditions.push('v.customer_id = ?');
        params.push(user.id);
      } else if (user.role === 'mechanic') {
        conditions.push('sa.mechanic_id = ?');
        params.push(user.id);
      }

      if (status) {
        conditions.push('s.status = ?');
        params.push(status);
      }

      if (startDate) {
        conditions.push('s.service_date >= ?');
        params.push(startDate);
      }

      if (endDate) {
        conditions.push('s.service_date <= ?');
        params.push(endDate);
      }

      if (search) {
        conditions.push('(v.vehicle_number LIKE ? OR c.name LIKE ? OR s.service_type LIKE ? OR m.name LIKE ?)');
        const s = `%${search.trim()}%`;
        params.push(s, s, s, s);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' ORDER BY s.service_date DESC, s.service_id DESC';

      const [services] = await db.query(query, params);
      res.json({ success: true, data: services });
    } catch (error) {
      console.error('Error fetching services:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve services.' });
    }
  },

  // Get service by ID
  getServiceById: async (req, res) => {
    try {
      const serviceId = parseInt(req.params.id, 10);
      const user = req.session.user;

      const [services] = await db.query(
        `SELECT s.*, 
                v.vehicle_number, v.vehicle_model, v.vehicle_type,
                c.customer_id, c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email, c.address AS customer_address,
                m.mechanic_id, m.name AS mechanic_name, m.phone AS mechanic_phone, m.specialization AS mechanic_specialization,
                sa.assignment_id, sa.remarks AS mechanic_remarks, sa.assigned_date,
                COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0) AS total_paid,
                (s.service_charge - COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0)) AS remaining_balance
         FROM services s
         JOIN vehicles v ON s.vehicle_id = v.vehicle_id
         JOIN customers c ON v.customer_id = c.customer_id
         LEFT JOIN service_assignments sa ON s.service_id = sa.service_id
         LEFT JOIN mechanics m ON sa.mechanic_id = m.mechanic_id
         WHERE s.service_id = ?`,
        [serviceId]
      );

      if (services.length === 0) {
        return res.status(404).json({ success: false, message: 'Service record not found.' });
      }

      const service = services[0];

      // Check role permissions
      if (user.role === 'customer' && service.customer_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden. You do not own this vehicle.' });
      }

      if (user.role === 'mechanic' && service.mechanic_id !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden. This service is not assigned to you.' });
      }

      // Fetch payment list
      const [payments] = await db.query(
        'SELECT * FROM payments WHERE service_id = ? ORDER BY payment_date DESC, payment_id DESC',
        [serviceId]
      );

      res.json({
        success: true,
        data: {
          ...service,
          payments
        }
      });
    } catch (error) {
      console.error('Error fetching service details:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve service details.' });
    }
  },

  // Create service record (Admin only)
  createService: async (req, res) => {
    try {
      const { vehicle_id, service_type, service_date, description, service_charge, status, mechanic_id } = req.body;

      if (!vehicle_id || !service_type || !service_date) {
        return res.status(400).json({ success: false, message: 'Vehicle, service type, and service date are required.' });
      }

      const charge = parseFloat(service_charge) || 0.00;
      if (charge < 0) {
        return res.status(400).json({ success: false, message: 'Service charge must be a positive number.' });
      }

      const sStatus = status && validStatuses.includes(status) ? status : 'Received';

      // Verify vehicle exists
      const [veh] = await db.query('SELECT vehicle_id FROM vehicles WHERE vehicle_id = ?', [vehicle_id]);
      if (veh.length === 0) {
        return res.status(404).json({ success: false, message: 'Vehicle not found.' });
      }

      const [result] = await db.query(
        `INSERT INTO services (vehicle_id, service_type, service_date, description, service_charge, status)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [vehicle_id, service_type.trim(), service_date, (description || '').trim(), charge, sStatus]
      );

      const serviceId = result.insertId;

      // Assign mechanic if provided
      if (mechanic_id) {
        await db.query(
          `INSERT INTO service_assignments (service_id, mechanic_id, remarks)
           VALUES (?, ?, ?)`,
          [serviceId, mechanic_id, 'Initially assigned on creation']
        );
      }

      res.status(201).json({
        success: true,
        message: 'Service record created successfully.',
        serviceId
      });
    } catch (error) {
      console.error('Error creating service:', error);
      res.status(500).json({ success: false, message: 'Failed to create service record.' });
    }
  },

  // Update service details (Admin only)
  updateService: async (req, res) => {
    try {
      const serviceId = parseInt(req.params.id, 10);
      const { vehicle_id, service_type, service_date, description, service_charge, status, mechanic_id, remarks } = req.body;

      if (!service_type || !service_date) {
        return res.status(400).json({ success: false, message: 'Service type and date are required.' });
      }

      const charge = parseFloat(service_charge) || 0.00;
      if (charge < 0) {
        return res.status(400).json({ success: false, message: 'Service charge must be positive.' });
      }

      if (status && !validStatuses.includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid service status.' });
      }

      // Check existing payments to ensure charge is not lower than already paid amount
      const [paySum] = await db.query(
        'SELECT COALESCE(SUM(amount), 0) AS total_paid FROM payments WHERE service_id = ? AND status = "Paid"',
        [serviceId]
      );
      const totalPaid = parseFloat(paySum[0].total_paid) || 0.00;

      if (charge < totalPaid) {
        return res.status(400).json({
          success: false,
          message: `Cannot set service charge ($${charge.toFixed(2)}) lower than total already paid ($${totalPaid.toFixed(2)}).`
        });
      }

      await db.query(
        `UPDATE services 
         SET vehicle_id = COALESCE(?, vehicle_id), 
             service_type = ?, 
             service_date = ?, 
             description = ?, 
             service_charge = ?, 
             status = ?
         WHERE service_id = ?`,
        [vehicle_id || null, service_type.trim(), service_date, (description || '').trim(), charge, status, serviceId]
      );

      // Handle mechanic assignment/reassignment
      if (mechanic_id) {
        const [existingAssignment] = await db.query(
          'SELECT assignment_id FROM service_assignments WHERE service_id = ?',
          [serviceId]
        );

        if (existingAssignment.length > 0) {
          await db.query(
            'UPDATE service_assignments SET mechanic_id = ?, remarks = COALESCE(?, remarks) WHERE service_id = ?',
            [mechanic_id, remarks, serviceId]
          );
        } else {
          await db.query(
            'INSERT INTO service_assignments (service_id, mechanic_id, remarks) VALUES (?, ?, ?)',
            [serviceId, mechanic_id, remarks || 'Assigned by admin']
          );
        }
      }

      res.json({ success: true, message: 'Service record updated successfully.' });
    } catch (error) {
      console.error('Error updating service:', error);
      res.status(500).json({ success: false, message: 'Failed to update service record.' });
    }
  },

  // Mechanic progress update (Mechanic cannot edit charges or payments)
  mechanicUpdate: async (req, res) => {
    try {
      const serviceId = parseInt(req.params.id, 10);
      const user = req.session.user;
      const { status, remarks } = req.body;

      if (!status || !validStatuses.includes(status)) {
        return res.status(400).json({ success: false, message: 'A valid status is required.' });
      }

      // Verify that this service is assigned to this mechanic
      const [assignment] = await db.query(
        'SELECT * FROM service_assignments WHERE service_id = ? AND mechanic_id = ?',
        [serviceId, user.id]
      );

      if (assignment.length === 0) {
        return res.status(403).json({ success: false, message: 'You are not assigned to this service.' });
      }

      // Update status on service
      await db.query('UPDATE services SET status = ? WHERE service_id = ?', [status, serviceId]);

      // Update remarks on assignment
      if (remarks !== undefined) {
        await db.query(
          'UPDATE service_assignments SET remarks = ? WHERE service_id = ? AND mechanic_id = ?',
          [(remarks || '').trim(), serviceId, user.id]
        );
      }

      res.json({
        success: true,
        message: 'Service progress and remarks updated successfully.'
      });
    } catch (error) {
      console.error('Error updating mechanic progress:', error);
      res.status(500).json({ success: false, message: 'Failed to update progress.' });
    }
  },

  // Safe delete service record (Admin only)
  deleteService: async (req, res) => {
    try {
      const serviceId = parseInt(req.params.id, 10);

      // Check if payments exist
      const [payments] = await db.query('SELECT payment_id FROM payments WHERE service_id = ?', [serviceId]);
      if (payments.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete service record with recorded payments. Financial records must be preserved.'
        });
      }

      // Check status
      const [service] = await db.query('SELECT status FROM services WHERE service_id = ?', [serviceId]);
      if (service.length === 0) {
        return res.status(404).json({ success: false, message: 'Service not found.' });
      }

      if (service[0].status === 'Delivered' || service[0].status === 'Completed') {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete completed or delivered service records.'
        });
      }

      await db.query('DELETE FROM services WHERE service_id = ?', [serviceId]);
      res.json({ success: true, message: 'Service record deleted successfully.' });
    } catch (error) {
      console.error('Error deleting service:', error);
      res.status(500).json({ success: false, message: 'Failed to delete service.' });
    }
  }
};

module.exports = serviceController;
