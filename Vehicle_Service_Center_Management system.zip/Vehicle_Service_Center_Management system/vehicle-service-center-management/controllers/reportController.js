const db = require('../config/db');

const reportController = {
  // 1. Customer-wise report
  getCustomerWiseReport: async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      let dateFilter = '';
      const params = [];

      if (startDate) {
        dateFilter += ' AND s.service_date >= ?';
        params.push(startDate);
      }
      if (endDate) {
        dateFilter += ' AND s.service_date <= ?';
        params.push(endDate);
      }

      const query = `
        SELECT c.customer_id, c.name AS customer_name, c.phone, c.email,
               COUNT(DISTINCT v.vehicle_id) AS total_vehicles,
               COUNT(DISTINCT s.service_id) AS total_services,
               COALESCE(SUM(s.service_charge), 0) AS total_charges,
               COALESCE(SUM(p.amount), 0) AS total_paid,
               (COALESCE(SUM(s.service_charge), 0) - COALESCE(SUM(p.amount), 0)) AS balance_due
        FROM customers c
        LEFT JOIN vehicles v ON c.customer_id = v.customer_id
        LEFT JOIN services s ON v.vehicle_id = s.vehicle_id ${dateFilter}
        LEFT JOIN payments p ON s.service_id = p.service_id AND p.status = 'Paid'
        GROUP BY c.customer_id
        ORDER BY total_services DESC, total_charges DESC
      `;

      const [rows] = await db.query(query, params);
      res.json({ success: true, data: rows });
    } catch (error) {
      console.error('Customer report error:', error);
      res.status(500).json({ success: false, message: 'Failed to generate customer report.' });
    }
  },

  // 2. Vehicle-wise report
  getVehicleWiseReport: async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      let dateFilter = '';
      const params = [];

      if (startDate) {
        dateFilter += ' AND s.service_date >= ?';
        params.push(startDate);
      }
      if (endDate) {
        dateFilter += ' AND s.service_date <= ?';
        params.push(endDate);
      }

      const query = `
        SELECT v.vehicle_id, v.vehicle_number, v.vehicle_model, v.vehicle_type,
               c.name AS owner_name, c.phone AS owner_phone,
               COUNT(s.service_id) AS total_services,
               COALESCE(SUM(s.service_charge), 0) AS total_spent,
               COALESCE(SUM(p.amount), 0) AS total_paid,
               MAX(s.service_date) AS last_service_date
        FROM vehicles v
        JOIN customers c ON v.customer_id = c.customer_id
        LEFT JOIN services s ON v.vehicle_id = s.vehicle_id ${dateFilter}
        LEFT JOIN payments p ON s.service_id = p.service_id AND p.status = 'Paid'
        GROUP BY v.vehicle_id
        ORDER BY total_services DESC
      `;

      const [rows] = await db.query(query, params);
      res.json({ success: true, data: rows });
    } catch (error) {
      console.error('Vehicle report error:', error);
      res.status(500).json({ success: false, message: 'Failed to generate vehicle report.' });
    }
  },

  // 3. Daily & Monthly service records
  getServiceTimelineReport: async (req, res) => {
    try {
      const { groupBy, startDate, endDate } = req.query; // groupBy: 'daily' or 'monthly'
      const isDaily = groupBy !== 'monthly';

      const dateFormat = isDaily ? '%Y-%m-%d' : '%Y-%m';
      const conditions = [];
      const params = [];

      if (startDate) {
        conditions.push('s.service_date >= ?');
        params.push(startDate);
      }
      if (endDate) {
        conditions.push('s.service_date <= ?');
        params.push(endDate);
      }

      const whereClause = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : '';

      const query = `
        SELECT DATE_FORMAT(s.service_date, '${dateFormat}') AS period,
               COUNT(s.service_id) AS total_services,
               SUM(CASE WHEN s.status IN ('Completed', 'Delivered') THEN 1 ELSE 0 END) AS completed_count,
               SUM(CASE WHEN s.status NOT IN ('Completed', 'Delivered', 'Cancelled') THEN 1 ELSE 0 END) AS pending_count,
               COALESCE(SUM(s.service_charge), 0) AS total_billing
        FROM services s
        ${whereClause}
        GROUP BY period
        ORDER BY period DESC
      `;

      const [rows] = await db.query(query, params);
      res.json({ success: true, groupBy: isDaily ? 'daily' : 'monthly', data: rows });
    } catch (error) {
      console.error('Timeline report error:', error);
      res.status(500).json({ success: false, message: 'Failed to generate timeline report.' });
    }
  },

  // 4. Mechanic-wise assignments report
  getMechanicReport: async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      let dateFilter = '';
      const params = [];

      if (startDate) {
        dateFilter += ' AND s.service_date >= ?';
        params.push(startDate);
      }
      if (endDate) {
        dateFilter += ' AND s.service_date <= ?';
        params.push(endDate);
      }

      const query = `
        SELECT m.mechanic_id, m.name AS mechanic_name, m.phone, m.specialization, m.status AS mechanic_status,
               COUNT(sa.assignment_id) AS total_jobs,
               SUM(CASE WHEN s.status IN ('Completed', 'Delivered') THEN 1 ELSE 0 END) AS completed_jobs,
               SUM(CASE WHEN s.status NOT IN ('Completed', 'Delivered', 'Cancelled') THEN 1 ELSE 0 END) AS active_jobs,
               COALESCE(SUM(s.service_charge), 0) AS total_billed_work
        FROM mechanics m
        LEFT JOIN service_assignments sa ON m.mechanic_id = sa.mechanic_id
        LEFT JOIN services s ON sa.service_id = s.service_id ${dateFilter}
        GROUP BY m.mechanic_id
        ORDER BY total_jobs DESC
      `;

      const [rows] = await db.query(query, params);
      res.json({ success: true, data: rows });
    } catch (error) {
      console.error('Mechanic report error:', error);
      res.status(500).json({ success: false, message: 'Failed to generate mechanic report.' });
    }
  },

  // 5. Payment Collections report
  getPaymentCollectionsReport: async (req, res) => {
    try {
      const { startDate, endDate, method } = req.query;
      const conditions = [];
      const params = [];

      if (startDate) {
        conditions.push('p.payment_date >= ?');
        params.push(startDate);
      }
      if (endDate) {
        conditions.push('p.payment_date <= ?');
        params.push(endDate);
      }
      if (method) {
        conditions.push('p.payment_method = ?');
        params.push(method);
      }

      const whereClause = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : '';

      const query = `
        SELECT p.payment_id, p.receipt_number, p.payment_date, p.amount, p.payment_method, p.status,
               s.service_id, s.service_type, s.service_charge,
               v.vehicle_number,
               c.name AS customer_name, c.phone AS customer_phone
        FROM payments p
        JOIN services s ON p.service_id = s.service_id
        JOIN vehicles v ON s.vehicle_id = v.vehicle_id
        JOIN customers c ON v.customer_id = c.customer_id
        ${whereClause}
        ORDER BY p.payment_date DESC, p.payment_id DESC
      `;

      const [rows] = await db.query(query, params);

      // Also get method breakdown
      const [breakdown] = await db.query(`
        SELECT payment_method, COUNT(*) AS count, COALESCE(SUM(amount), 0) AS total
        FROM payments
        ${whereClause}
        GROUP BY payment_method
      `, params);

      const totalRevenue = rows.reduce((acc, curr) => acc + parseFloat(curr.amount), 0);

      res.json({
        success: true,
        summary: {
          totalCollections: totalRevenue,
          totalTransactions: rows.length,
          breakdown
        },
        data: rows
      });
    } catch (error) {
      console.error('Payment report error:', error);
      res.status(500).json({ success: false, message: 'Failed to generate payment collections report.' });
    }
  },

  // 6. Pending payments report (Outstanding balances)
  getPendingPaymentsReport: async (req, res) => {
    try {
      const query = `
        SELECT s.service_id, s.service_type, s.service_date, s.service_charge, s.status AS service_status,
               v.vehicle_number, v.vehicle_model,
               c.customer_id, c.name AS customer_name, c.phone AS customer_phone, c.email AS customer_email,
               COALESCE(SUM(p.amount), 0) AS total_paid,
               (s.service_charge - COALESCE(SUM(p.amount), 0)) AS balance_due
        FROM services s
        JOIN vehicles v ON s.vehicle_id = v.vehicle_id
        JOIN customers c ON v.customer_id = c.customer_id
        LEFT JOIN payments p ON s.service_id = p.service_id AND p.status = 'Paid'
        WHERE s.status != 'Cancelled'
        GROUP BY s.service_id
        HAVING balance_due > 0
        ORDER BY balance_due DESC, s.service_date ASC
      `;

      const [rows] = await db.query(query);
      const totalOutstanding = rows.reduce((acc, curr) => acc + parseFloat(curr.balance_due), 0);

      res.json({
        success: true,
        summary: {
          totalPendingServices: rows.length,
          totalOutstandingBalance: totalOutstanding
        },
        data: rows
      });
    } catch (error) {
      console.error('Pending payments report error:', error);
      res.status(500).json({ success: false, message: 'Failed to generate pending payments report.' });
    }
  },

  // 7. Service-type breakdown report
  getServiceTypeReport: async (req, res) => {
    try {
      const query = `
        SELECT service_type,
               COUNT(service_id) AS total_count,
               SUM(CASE WHEN status IN ('Completed', 'Delivered') THEN 1 ELSE 0 END) AS completed_count,
               COALESCE(AVG(service_charge), 0) AS avg_charge,
               COALESCE(SUM(service_charge), 0) AS total_revenue
        FROM services
        GROUP BY service_type
        ORDER BY total_count DESC
      `;

      const [rows] = await db.query(query);
      res.json({ success: true, data: rows });
    } catch (error) {
      console.error('Service type report error:', error);
      res.status(500).json({ success: false, message: 'Failed to generate service type report.' });
    }
  }
};

module.exports = reportController;
