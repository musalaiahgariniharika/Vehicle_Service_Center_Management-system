const db = require('../config/db');

const dashboardController = {
  getStats: async (req, res) => {
    try {
      const user = req.session.user;

      if (user.role === 'admin') {
        // Admin stats
        const [customerCount] = await db.query('SELECT COUNT(*) AS count FROM customers');
        const [vehicleCount] = await db.query('SELECT COUNT(*) AS count FROM vehicles');
        const [mechanicCount] = await db.query('SELECT COUNT(*) AS count FROM mechanics WHERE status = "Active"');
        const [appointmentCount] = await db.query('SELECT COUNT(*) AS count FROM appointments');
        const [serviceCount] = await db.query('SELECT COUNT(*) AS count FROM services');
        const [pendingServices] = await db.query('SELECT COUNT(*) AS count FROM services WHERE status NOT IN ("Completed", "Delivered", "Cancelled")');
        const [completedServices] = await db.query('SELECT COUNT(*) AS count FROM services WHERE status IN ("Completed", "Delivered")');
        
        // Total revenue collected
        const [revenue] = await db.query('SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE status = "Paid"');
        
        // Pending payments: total charges of non-cancelled services minus total paid
        const [chargesSum] = await db.query('SELECT COALESCE(SUM(service_charge), 0) AS total FROM services WHERE status != "Cancelled"');
        const totalServiceCharges = parseFloat(chargesSum[0].total) || 0;
        const totalCollectedRevenue = parseFloat(revenue[0].total) || 0;
        const pendingPayments = Math.max(0, +(totalServiceCharges - totalCollectedRevenue).toFixed(2));

        // Recent appointments
        const [recentAppointments] = await db.query(`
          SELECT a.*, c.name AS customer_name, v.vehicle_number 
          FROM appointments a
          JOIN customers c ON a.customer_id = c.customer_id
          JOIN vehicles v ON a.vehicle_id = v.vehicle_id
          ORDER BY a.appointment_date DESC, a.appointment_time DESC
          LIMIT 5
        `);

        // Recent services
        const [recentServices] = await db.query(`
          SELECT s.*, c.name AS customer_name, v.vehicle_number, m.name AS mechanic_name
          FROM services s
          JOIN vehicles v ON s.vehicle_id = v.vehicle_id
          JOIN customers c ON v.customer_id = c.customer_id
          LEFT JOIN service_assignments sa ON s.service_id = sa.service_id
          LEFT JOIN mechanics m ON sa.mechanic_id = m.mechanic_id
          ORDER BY s.service_date DESC, s.service_id DESC
          LIMIT 5
        `);

        // Recent payments
        const [recentPayments] = await db.query(`
          SELECT p.*, c.name AS customer_name, v.vehicle_number
          FROM payments p
          JOIN services s ON p.service_id = s.service_id
          JOIN vehicles v ON s.vehicle_id = v.vehicle_id
          JOIN customers c ON v.customer_id = c.customer_id
          ORDER BY p.payment_date DESC, p.payment_id DESC
          LIMIT 5
        `);

        return res.json({
          success: true,
          role: 'admin',
          data: {
            totalCustomers: customerCount[0].count,
            totalVehicles: vehicleCount[0].count,
            totalMechanics: mechanicCount[0].count,
            totalAppointments: appointmentCount[0].count,
            totalServices: serviceCount[0].count,
            pendingServices: pendingServices[0].count,
            completedServices: completedServices[0].count,
            totalRevenue: totalCollectedRevenue,
            pendingPayments,
            recentAppointments,
            recentServices,
            recentPayments
          }
        });
      } else if (user.role === 'customer') {
        // Customer stats
        const customerId = user.id;

        const [vehicleCount] = await db.query('SELECT COUNT(*) AS count FROM vehicles WHERE customer_id = ?', [customerId]);
        const [appointmentCount] = await db.query('SELECT COUNT(*) AS count FROM appointments WHERE customer_id = ?', [customerId]);
        const [pendingAppointments] = await db.query(
          'SELECT COUNT(*) AS count FROM appointments WHERE customer_id = ? AND status = "Pending"',
          [customerId]
        );

        const [servicesStats] = await db.query(`
          SELECT 
            COUNT(s.service_id) AS total_services,
            SUM(CASE WHEN s.status NOT IN ('Completed', 'Delivered', 'Cancelled') THEN 1 ELSE 0 END) AS active_services,
            SUM(CASE WHEN s.status IN ('Completed', 'Delivered') THEN 1 ELSE 0 END) AS completed_services,
            COALESCE(SUM(s.service_charge), 0) AS total_charges
          FROM services s
          JOIN vehicles v ON s.vehicle_id = v.vehicle_id
          WHERE v.customer_id = ? AND s.status != 'Cancelled'
        `, [customerId]);

        const [paidSum] = await db.query(`
          SELECT COALESCE(SUM(p.amount), 0) AS total_paid
          FROM payments p
          JOIN services s ON p.service_id = s.service_id
          JOIN vehicles v ON s.vehicle_id = v.vehicle_id
          WHERE v.customer_id = ? AND p.status = 'Paid'
        `, [customerId]);

        const charges = parseFloat(servicesStats[0].total_charges) || 0;
        const paid = parseFloat(paidSum[0].total_paid) || 0;
        const pendingPaymentAmount = Math.max(0, +(charges - paid).toFixed(2));

        const [recentServices] = await db.query(`
          SELECT s.*, v.vehicle_number, v.vehicle_model,
                 COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0) AS total_paid,
                 (s.service_charge - COALESCE((SELECT SUM(amount) FROM payments WHERE service_id = s.service_id AND status = 'Paid'), 0)) AS remaining_balance
          FROM services s
          JOIN vehicles v ON s.vehicle_id = v.vehicle_id
          WHERE v.customer_id = ?
          ORDER BY s.service_date DESC, s.service_id DESC
          LIMIT 5
        `, [customerId]);

        const [myVehicles] = await db.query('SELECT * FROM vehicles WHERE customer_id = ?', [customerId]);

        return res.json({
          success: true,
          role: 'customer',
          data: {
            customer: user,
            totalVehicles: vehicleCount[0].count,
            totalAppointments: appointmentCount[0].count,
            pendingAppointments: pendingAppointments[0].count,
            activeServices: servicesStats[0].active_services || 0,
            completedServices: servicesStats[0].completed_services || 0,
            pendingPaymentAmount,
            recentServices,
            vehicles: myVehicles
          }
        });
      } else if (user.role === 'mechanic') {
        // Mechanic stats
        const mechanicId = user.id;

        const [assignments] = await db.query(`
          SELECT 
            COUNT(sa.assignment_id) AS total_assigned,
            SUM(CASE WHEN s.status IN ('Received', 'Inspection') THEN 1 ELSE 0 END) AS pending_work,
            SUM(CASE WHEN s.status IN ('In Progress', 'Waiting for Parts') THEN 1 ELSE 0 END) AS in_progress,
            SUM(CASE WHEN s.status IN ('Completed', 'Delivered') THEN 1 ELSE 0 END) AS completed_work
          FROM service_assignments sa
          JOIN services s ON sa.service_id = s.service_id
          WHERE sa.mechanic_id = ?
        `, [mechanicId]);

        const [recentAssignments] = await db.query(`
          SELECT sa.*, s.service_type, s.service_date, s.status AS service_status, s.description,
                 v.vehicle_number, v.vehicle_model, v.vehicle_type,
                 c.name AS customer_name, c.phone AS customer_phone
          FROM service_assignments sa
          JOIN services s ON sa.service_id = s.service_id
          JOIN vehicles v ON s.vehicle_id = v.vehicle_id
          JOIN customers c ON v.customer_id = c.customer_id
          WHERE sa.mechanic_id = ?
          ORDER BY sa.assigned_date DESC
          LIMIT 10
        `, [mechanicId]);

        return res.json({
          success: true,
          role: 'mechanic',
          data: {
            mechanic: user,
            totalAssigned: assignments[0].total_assigned || 0,
            pendingWork: assignments[0].pending_work || 0,
            inProgress: assignments[0].in_progress || 0,
            completedWork: assignments[0].completed_work || 0,
            recentAssignments
          }
        });
      }

      res.status(400).json({ success: false, message: 'Unknown role.' });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      res.status(500).json({ success: false, message: 'Failed to retrieve dashboard statistics.' });
    }
  }
};

module.exports = dashboardController;
